package Tutorial;

import java.io.File;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class FileChooserJavaFX extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX App");

        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
        	     new FileChooser.ExtensionFilter("Text Files", "*.txt")
        	    ,new FileChooser.ExtensionFilter("HTML Files", "*.htm")
        	);
        fileChooser.setInitialFileName("myfile.txt");
        fileChooser.setInitialDirectory(new File("C:\\Users\\shres\\Documents"));
        Button button = new Button("Select File");
        button.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(primaryStage);

            System.out.println(selectedFile.getAbsolutePath());
        });


        VBox vBox = new VBox(button);
        Scene scene = new Scene(vBox, 960, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}