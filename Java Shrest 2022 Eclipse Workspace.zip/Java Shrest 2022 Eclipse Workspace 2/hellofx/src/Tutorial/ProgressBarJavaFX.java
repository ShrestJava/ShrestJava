package Tutorial;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import java.io.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.net.*;
//sample class that extends application base class
public class ProgressBarJavaFX extends Application {
static double v =0;
//application starts here
public void start(Stage s) throws Exception {
// set title
s.setTitle("JavaFX Progress bar example");
//create progress bar
ProgressBar p = new ProgressBar(0);
// tile pane
TilePane tp = new TilePane();
// action event
EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {
public void handle(ActionEvent e)
{
// set progress to different level of progressbar
v += 0.1;
p.setProgress(v);
}
};
// creating button
Button btn = new Button("click me to move progress bar");
// set on action
btn.setOnAction(ev);
tp.getChildren().add(p);
tp.getChildren().add(btn);
//create the scene
Scene sc = new Scene(tp, 200, 200);
//set the scene
s.setScene(sc);
//display the result
s.show();
}
//main method
public static void main(String[] args) {
launch(args);
}
}
