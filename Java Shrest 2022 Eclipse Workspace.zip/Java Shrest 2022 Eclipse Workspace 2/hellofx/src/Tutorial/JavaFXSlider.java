package Tutorial;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JavaFXSlider extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX App");

        Slider slider = new Slider(0, 100, 0);

        slider.setMajorTickUnit(8.0); // The major tick unit is how many units the value changes every time the user moves the handle of the Slider one tick.

        slider.setMinorTickCount(3);  // The minor tick count specifies how many minor ticks there are between two of the major ticks.
        slider.setSnapToTicks(true); // snaps to ticks so you can't have a strange, funny number
        slider.setShowTickMarks(true); // Show tick marks
        slider.setShowTickLabels(true); // Show Tick Labels
        VBox vBox = new VBox(slider);
        Scene scene = new Scene(vBox, 960, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

}