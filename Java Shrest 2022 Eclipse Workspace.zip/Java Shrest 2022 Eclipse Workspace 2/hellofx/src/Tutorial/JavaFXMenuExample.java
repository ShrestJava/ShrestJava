package Tutorial;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
public class JavaFXMenuExample extends Application {
@Override
public void start(Stage s) {
//create border pane
BorderPane r = new BorderPane();
Scene scene = new Scene(r, 300, 250, Color.RED);
//create menubar
MenuBar mb = new MenuBar();
mb.prefWidthProperty().bind(s.widthProperty());
r.setTop(mb);
// first menu with sub items
Menu m = new Menu("Select your Age group");
MenuItem mi1 = new MenuItem("5-11");
MenuItem mi2 = new MenuItem("12-18");
MenuItem mi3 = new MenuItem("18+");
m.getItems().addAll(mi1,mi2,mi3);
// second menu with sub items
Menu m1 = new Menu("Favorite online site");

Slider slider = new Slider(0, 100, 50);

CustomMenuItem customMenuItem = new CustomMenuItem();
customMenuItem.setContent(slider);
customMenuItem.setHideOnClick(false);
m1.getItems().add(customMenuItem);

Button button = new Button("Custom Menu Item Button");
CustomMenuItem customMenuItem2 = new CustomMenuItem();
customMenuItem2.setContent(button);
customMenuItem2.setHideOnClick(false);
m1.getItems().add(customMenuItem2);
SeparatorMenuItem separator = new SeparatorMenuItem();
m1.getItems().add(separator);
RadioMenuItem choice1Item = new RadioMenuItem("Choice 1");
RadioMenuItem choice2Item = new RadioMenuItem("Choice 2");
RadioMenuItem choice3Item = new RadioMenuItem("Choice 3");

ToggleGroup toggleGroup = new ToggleGroup();
toggleGroup.getToggles().add(choice1Item);
toggleGroup.getToggles().add(choice2Item);
toggleGroup.getToggles().add(choice3Item);

m1.getItems().add(choice1Item);
m1.getItems().add(choice2Item);
m1.getItems().add(choice3Item);
MenuBar menuBar = new MenuBar();
menuBar.getMenus().add(m1);
ToggleGroup t1 = new ToggleGroup();
RadioMenuItem r1 = new RadioMenuItem("Amazon");
r1.setToggleGroup(t1);
RadioMenuItem r2 = new RadioMenuItem("Walmart");
r2.setToggleGroup(t1);
r2.setSelected(true);
m1.getItems().addAll(r1,r2);
Menu m2 = new Menu("Queries");
m2.getItems().addAll( new CheckMenuItem("Related to product"),
new CheckMenuItem("Related to delivery"));
m1.getItems().add(m2);
mb.getMenus().addAll(m, m1);
s.setScene(scene);
s.show();
}
public static void main(String[] args) {
launch(args);
}
}