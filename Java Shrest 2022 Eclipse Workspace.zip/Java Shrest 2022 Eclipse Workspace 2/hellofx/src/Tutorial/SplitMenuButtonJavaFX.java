package Tutorial;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class SplitMenuButtonJavaFX extends Application{
	  @Override
	    public void start(Stage primaryStage) throws Exception {
		  SplitMenuButton splitMenuButton = new SplitMenuButton();

		  Font font = Font.font("Courier New", FontWeight.BOLD, 36);
		  splitMenuButton.setFont(font);
		  
		  MenuItem choice1 = new MenuItem("Choice 1");
		  MenuItem choice2 = new MenuItem("Choice 2");
		  MenuItem choice3 = new MenuItem("Choice 3");


		  splitMenuButton.getItems().addAll(choice1, choice2, choice3);
		  choice1.setOnAction((e)-> {
		      System.out.println("Choice 1 selected");
		  });
		  choice2.setOnAction((e)-> {
		      System.out.println("Choice 2 selected");
		  });
		  choice3.setOnAction((e)-> {
		      System.out.println("Choice 3 selected");
		  });
		  splitMenuButton.setOnAction((e) -> {
			    System.out.println("SplitMenuButton clicked!");
			});

	        Scene scene = new Scene(splitMenuButton, 100, 25);
	        primaryStage.setScene(scene);
	        primaryStage.show();
	    }
	  public static void main(String[] args) {
		  Application.launch(args);
	}
}
