package Tutorial;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ScrollPaneJavaFX extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) throws FileNotFoundException {

    	ScrollPane scrollPane = new ScrollPane();

    	String imagePath = "C:\\Users\\shres\\Documents\\Shrest\\Pictures\\2014-10\\IMG_5209.JPG";
    	ImageView imageView = new ImageView(new Image(new FileInputStream(imagePath)));

    	scrollPane.setContent(imageView);
        VBox vBox = new VBox(scrollPane);
        Scene scene = new Scene(vBox, 960, 600);

        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX App");

        primaryStage.show();
    }
}