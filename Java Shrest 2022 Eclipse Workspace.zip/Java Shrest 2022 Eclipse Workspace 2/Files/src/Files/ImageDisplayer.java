package Files;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class ImageDisplayer {

	// *** your image path will be different *****

	public static void main(String[] args) {
		JFileChooser fc = new JFileChooser();
		int result = fc.showOpenDialog(null);
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			try {
				BufferedImage img = ImageIO.read(file);
				ImageIcon icon = new ImageIcon(img);
				JLabel label = new JLabel(icon);
				JOptionPane.showMessageDialog(null, label);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
