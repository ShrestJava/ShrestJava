package Files;

import java.io.IOException;

public class OpenExe_With_AppCode {

	public static void main(String[] args) {
		try {
			System.out.println("Opening notepad");
			Runtime runTime = Runtime.getRuntime();
			// calc for calculator
			// notepad for notepad
			Process process = runTime.exec("calc");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}