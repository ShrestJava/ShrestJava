package Files;

import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.groupdocs.viewer.Viewer;
import com.groupdocs.viewer.options.PngViewOptions;

public class FileToPNG {
public static void main(String[] args) throws MalformedURLException {
	// Instantiate viewer
	try (Viewer viewer = new Viewer("C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\My First Java App\\Icon.ico"))// it can be a lot of other types of files All supported files at the bottom

	{
		// Set view options
		PngViewOptions viewOptions = new PngViewOptions();
		// Convert file to PNG and check the output in the current directory
		viewer.view(viewOptions);
		URL url = new URL("file:///C:/Users/shres/Documents/Java%20Shrest%202022%20Eclipse%20Workspace/Java/p_1.png");// File of eclipse workspace and project make sure it says p_1.png
		Icon icon1 = new ImageIcon(url);

		
		JLabel label2 = new JLabel(icon1);
		
		JFrame f1 = new JFrame("File");
		f1.getContentPane().add(label2);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f1.pack();
		f1.setLocationRelativeTo(null);
		f1.setVisible(true);
	}
}
}
//Java DOC Viewer
//(Microsoft Word Document)
//
//Java DOCM Viewer
//(Microsoft Word Macro-Enabled Document)
//
//Java DOCX Viewer
//(Microsoft Word Open XML Document)
//
//Java DOT Viewer
//(Microsoft Word Document Template)
//
//Java DOTM Viewer
//(Microsoft Word Macro-Enabled Template)
//
//Java DOTX Viewer
//(Word Open XML Document Template)
//
//Java RTF Viewer
//(Rich Text File Format)
//
//Java TXT Viewer
//(Plain Text File Format)
//
//Java XLS Viewer
//(Microsoft Excel Binary File Format)
//
//Java XLSX Viewer
//(Microsoft Excel Open XML Spreadsheet)
//
//Java XLSM Viewer
//(Microsoft Excel Macro-Enabled Spreadsheet)
//
//Java XLSB Viewer
//(Microsoft Excel Binary Spreadsheet File)
//
//Java XLTX Viewer
//(Microsoft Excel Open XML Template)
//
//Java TSV Viewer
//(Tab Separated Values File)
//
//Java XLAM Viewer
//(Microsoft Excel Macro-Enabled Add-In)
//
//Java CSV Viewer
//(Comma Separated Values File)
//
//Java PPT Viewer
//(PowerPoint Presentation)
//
//Java PPS Viewer
//(Microsoft PowerPoint Slide Show)
//
//Java PPTX Viewer
//(PowerPoint Open XML Presentation)
//
//Java PPSX Viewer
//(PowerPoint Open XML Slide Show)
//
//Java POTX Viewer
//(Microsoft PowerPoint Open XML Template)
//
//Java POTM Viewer
//(Microsoft PowerPoint Template)
//
//Java PPTM Viewer
//(Microsoft PowerPoint Presentation)
//
//Java PPSM Viewer
//(Microsoft PowerPoint Slide Show)
//
//Java PDF Viewer
//(Adobe Portable Document Format)
//
//Java XPS Viewer
//(Open XML Paper Specification)
//
//Java TEX Viewer
//(LaTeX Source Document)
//
//Java ODS Viewer
//(Open Document Spreadsheet)
//
//Java ODP Viewer
//(OpenDocument Presentation File Format)
//
//Java OTP Viewer
//(Origin Graph Template)
//
//Java ODT Viewer
//(Open Document Text)
//
//Java OTT Viewer
//(Open Document Template)
//
//Java VST Viewer
//(Microsoft Visio 2003-2010 XML Drawing)
//
//Java TIFF Viewer
//(Tagged Image File Format)
//
//Java JPEG Viewer
//(JPEG Image)
//
//Java PNG Viewer
//(Portable Network Graphic)
//
//Java GIF Viewer
//(Graphical Interchange Format File)
//
//Java BMP Viewer
//(Bitmap File Format)
//
//Java ICO Viewer
//(Microsoft Icon File)
//
//Java PSD Viewer
//(Adobe Photoshop Document)
//
//Java WMF Viewer
//(Windows Metafile)
//
//Java EMF Viewer
//(Enhanced Metafile Format)
//
//Java WEBP Viewer
//(Raster Web Image File Format)
//
//Java SVG Viewer
//(Scalable Vector Graphics File)
//
//Java JP2 Viewer
//(JPEG 2000 Core Image File)
//
//Java MPP Viewer
//(Microsoft Project Document)
//
//Java MPT Viewer
//(Microsoft Project Template)
//
//Java HTML Viewer
//(Hyper Text Markup Language)
//
//Java MHT Viewer
//(MIME Encapsulation of Aggregate HTML)
//
//Java MHTML Viewer
//(MIME Encapsulation of Aggregate HTML)
//
//Java MSG Viewer
//(Microsoft Outlook E-mail Message)
//
//Java EML Viewer
//(E-mail Message)
//
//Java ONE Viewer
//(Microsoft OneNote)
//
//Java WMF Viewer
//(Windows Metafile)
//
//Java EMF Viewer
//(Windows Enhanced Metafile)
//
//Java PSD Viewer
//(Adobe Photoshop Document)
//
//Java VSD Viewer
//(Microsoft Visio 2003-2010 Drawing)
//
//Java VSDX Viewer
//(Microsoft Visio Drawing)
//
//Java VSS Viewer
//(Microsoft Visio 2003-2010 Stencil)
//
//Java VDX Viewer
//(Microsoft Visio 2003-2010 XML Drawing)
//
//Java VDW Viewer
//(Microsoft Visio 2010 Web Drawing)
//
//Java EPUB Viewer
//(Digital E-Book File Format)