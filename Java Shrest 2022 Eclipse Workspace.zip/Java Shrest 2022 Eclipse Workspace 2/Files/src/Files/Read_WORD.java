package Files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

public class Read_WORD {

	public static void main(String[] args) throws IOException {

		String fileName = "C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Desktop\\HI1.docx";

		try (XWPFDocument doc = new XWPFDocument(Files.newInputStream(Paths.get(fileName)))) {

			XWPFWordExtractor xwpfWordExtractor = new XWPFWordExtractor(doc);
			String docText = xwpfWordExtractor.getText();
			System.out.println(docText);

			// find number of words in the document
			long count = Arrays.stream(docText.split("\\s+")).count();
			System.out.println("Total words: " + count);

		}

	}

}