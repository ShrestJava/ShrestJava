package Files;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.github.sarxos.webcam.Webcam;

public class Webcam_Picture_Taker {
	public static void main(String[] args) throws IOException {
		Webcam webcam = Webcam.getDefault();
		webcam.open();
		ImageIO.write(webcam.getImage(), "JPG", new File(
				"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\IMAGE TAKEN FROM WEBCAM IN JAVA 2.jpg"));
	}
}
