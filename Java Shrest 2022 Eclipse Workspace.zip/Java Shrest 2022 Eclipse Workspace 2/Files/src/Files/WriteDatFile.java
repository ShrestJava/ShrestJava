package Files;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

public class WriteDatFile {

	public static void main(final String[] args) {

		try {
			final File file = new File(
					"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\DAT_FILE_WRITTEN_WITH_JAVA.dat");

			final PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));

			out.println("Java is a great programming language.");
			out.close();

		}

		catch (final Exception e) {
			System.out.println("error");
		}
	}
}
