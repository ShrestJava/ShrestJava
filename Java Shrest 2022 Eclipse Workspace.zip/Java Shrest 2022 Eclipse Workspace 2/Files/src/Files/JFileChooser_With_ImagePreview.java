package Files;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingWorker;
import javax.swing.filechooser.FileNameExtensionFilter;

public class JFileChooser_With_ImagePreview extends JFrame {
	JLabel img;
	JButton open;
	JFileChooser jf = new JFileChooser();

	public JFileChooser_With_ImagePreview() {
		createAndShowGUI();
	}

	private void createAndShowGUI() {
		setTitle("Image Preview for JFileChooser");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());

		// Create label
		img = new JLabel();

		img.setPreferredSize(new Dimension(175, 175));

		// Set label as accessory
		jf.setAccessory(img);

		// Accept only image files
		jf.setAcceptAllFileFilterUsed(false);

		// Create filter for image files
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif");

		// Set it as current filter
		jf.setFileFilter(filter);

		// Add property change listener
		jf.addPropertyChangeListener(new PropertyChangeListener() {

			// When any JFileChooser property changes, this handler
			// is executed
			public void propertyChange(final PropertyChangeEvent pe) {
				// Create SwingWorker for smooth experience
				SwingWorker<Image, Void> worker = new SwingWorker<Image, Void>() {

					// The image processing method
					protected Image doInBackground() {
						// If selected file changes..
						if (pe.getPropertyName().equals(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
							// Get selected file
							File f = jf.getSelectedFile();

							try {
								// Create FileInputStream for file
								FileInputStream fin = new FileInputStream(f);

								// Read image from fin
								BufferedImage bim = ImageIO.read(fin);

								// Return the scaled version of image
								return bim.getScaledInstance(178, 170, BufferedImage.SCALE_FAST);

							} catch (Exception e) {
								// If there is a problem reading image,
								// it might not be a valid image or unable
								// to read
								img.setText(" Not valid image/Unable to read");
							}
						}

						return null;
					}

					protected void done() {
						try {
							// Get the image
							Image i = get(1L, TimeUnit.NANOSECONDS);

							// If i is null, go back!
							if (i == null)
								return;

							// Set icon otherwise
							img.setIcon(new ImageIcon(i));
						} catch (Exception e) {
							// Print error occured
							img.setText(" Error occured.");
						}
					}
				};

				// Start worker thread
				worker.execute();
			}
		});

		// Create JButton
		open = new JButton("Open File Chooser");
		add(open);
		open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				// Show open dialog
				jf.showOpenDialog(null);
			}
		});

		setSize(400, 400);
		setVisible(true);
	}

	public static void main(String args[]) {
		new JFileChooser_With_ImagePreview();
	}
}
