package Files;

import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class ReadXML extends AbstractTableModel {
	Vector data;
	Vector columns;

	public ReadXML() {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse("C:\\Users\\shres\\Desktop\\XML.xml");

			NodeList n3 = doc.getElementsByTagName("lastname");
			NodeList n1 = doc.getElementsByTagName("id");
			NodeList n2 = doc.getElementsByTagName("firstname");
			NodeList n4 = doc.getElementsByTagName("subject");
			NodeList n5 = doc.getElementsByTagName("marks");
			NodeList listOfPersons = doc.getElementsByTagName("student");
			String data1 = "", data2 = "", data3 = "", data4 = "", data5 = "";
			data = new Vector();
			columns = new Vector();
			for (int i = 0; i < listOfPersons.getLength(); i++) {
				data1 = n1.item(i).getFirstChild().getNodeValue();
				data2 = n2.item(i).getFirstChild().getNodeValue();
				data3 = n3.item(i).getFirstChild().getNodeValue();
				data4 = n4.item(i).getFirstChild().getNodeValue();
				data5 = n5.item(i).getFirstChild().getNodeValue();
				String line = data1 + " " + data2 + " " + data3 + " " + data4 + " " + data5;
				StringTokenizer st2 = new StringTokenizer(line, " ");
				while (st2.hasMoreTokens())
					data.addElement(st2.nextToken());
			}
			columns.add("");
			columns.add("");
			columns.add("");
			columns.add("");
			columns.add("");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getRowCount() {
		return data.size() / getColumnCount();
	}

	public int getColumnCount() {
		return columns.size();
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		return (String) data.elementAt((rowIndex * getColumnCount()) + columnIndex);
	}

	public static void main(String argv[]) throws Exception {
		ReadXML t = new ReadXML();
		JTable table = new JTable();
		table.setModel(t);
		JScrollPane scrollpane = new JScrollPane(table);
		JPanel panel = new JPanel();
		panel.add(scrollpane);
		JFrame frame = new JFrame();
		frame.add(panel, "Center");
		frame.pack();
		frame.setVisible(true);
	}
}