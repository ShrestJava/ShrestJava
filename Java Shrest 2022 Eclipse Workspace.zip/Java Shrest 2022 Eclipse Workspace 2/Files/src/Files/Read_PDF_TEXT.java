package Files;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class Read_PDF_TEXT {

	public static void main(String[] args) throws Exception {

		try (PDDocument document = PDDocument.load(new File(
				"C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Downloads\\hi22.pdf"))) {

			if (!document.isEncrypted()) {
				PDFTextStripper tStripper = new PDFTextStripper();
				String pdfFileInText = tStripper.getText(document);
				String lines[] = pdfFileInText.split("\\r?\\n");
				for (String line : lines) {
					System.out.println(line);
				}
			}
		} catch (IOException e) {
			System.err.println("Exception while trying to read pdf document - " + e);
		}
	}

}