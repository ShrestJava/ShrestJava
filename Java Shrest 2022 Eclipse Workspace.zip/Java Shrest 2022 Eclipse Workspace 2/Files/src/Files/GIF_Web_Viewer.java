package Files;

import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GIF_Web_Viewer {
	public static void main(String[] args) throws MalformedURLException {

		URL url = new URL("https://i.pinimg.com/originals/e6/32/85/e63285cbfabd350591fdeec4b64d01a0.gif");
		Icon icon = new ImageIcon(url);
		JLabel label = new JLabel(icon);

		JFrame f = new JFrame("Animation");
		f.getContentPane().add(label);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
}