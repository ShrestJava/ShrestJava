package Files;

import java.io.FileWriter;
import java.io.IOException;

public class WRITE_TXT {

	public static void main(String[] args) {
		try {
			FileWriter writer = new FileWriter(
					"C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\Java Created Files\\TXT FILE WRITTEN WITH JAVA.txt",
					true);
			writer.write("123123");
			writer.write("\r\n"); // write new line
			writer.write("Shrest The Best!!!");

			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}