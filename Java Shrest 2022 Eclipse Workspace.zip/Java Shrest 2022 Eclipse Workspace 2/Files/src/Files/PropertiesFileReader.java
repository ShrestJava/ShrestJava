package Files;

import java.io.FileReader;
import java.util.Properties;

public class PropertiesFileReader {
	public static void main(String[] args) throws Exception {
		FileReader reader = new FileReader(
				"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\PROPERTIES FILE WRITTEN WITH JAVA.properties");

		Properties p = new Properties();
		p.load(reader);

		System.out.println(p.getProperty("Name: "));
		System.out.println(p.getProperty("Future Career: "));
	}
}