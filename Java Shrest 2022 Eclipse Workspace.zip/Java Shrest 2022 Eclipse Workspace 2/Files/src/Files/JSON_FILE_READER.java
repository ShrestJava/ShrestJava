package Files;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSON_FILE_READER {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {

		JSONParser parser = new JSONParser();
		JSONArray a = (JSONArray) parser.parse(new FileReader("C:\\Users\\shres\\Documents\\Json.json"));

		for (Object o : a) {
			JSONObject person = (JSONObject) o;

			String name = (String) person.get("name");
			System.out.println("Name: " + name);

			String city = (String) person.get("city");
			System.out.println("   City: " + city);

			String job = (String) person.get("future job");
			System.out.println("      Future Job: " + job);

			JSONArray things = (JSONArray) person.get("programming languages fammilliar with");
			if (things.isEmpty() == false) {
				for (Object c : things) {
					System.out.println("         Programming Languages Familliar with: " + c);
				}
			}
		}

	}
}