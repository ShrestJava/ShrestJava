package Files;

import java.awt.Color;
import java.awt.Rectangle;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.sl.usermodel.AutoNumberingScheme;
import org.apache.poi.sl.usermodel.PictureData;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xslf.usermodel.SlideLayout;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFHyperlink;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideLayout;
import org.apache.poi.xslf.usermodel.XSLFSlideMaster;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.apache.poi.xslf.usermodel.XSLFTextShape;

// We are going to create a Microsoft PowerPoint Document with 3 Slides
// For that, we are going to use Apache POI Library
// We need to add dependencies in the POM of our project
// We are going to create PPTX so we will use XML Model
public class CREATE_POWERPOINT_FILE {

	public static void main(String[] args) throws Exception {
		// we are new PPTX Presentation
		XMLSlideShow ppt = new XMLSlideShow();
		// we add a new slide
		XSLFSlideMaster defaultMaster = ppt.getSlideMasters().get(0);
		// retrieving a the slide layout
		XSLFSlideLayout layout = defaultMaster.getLayout(SlideLayout.TITLE_ONLY);

		// we create the first slide
		XSLFSlide slide = ppt.createSlide(layout);
		XSLFTextShape title = slide.getPlaceholder(0);
		// we remove the predefined text
		title.clearText();

		// we create a new paragraph
		XSLFTextParagraph p = title.addNewTextParagraph();
		XSLFTextRun r = p.addNewTextRun();
		r.setText("Shrest The Best");
		r.setFontColor(Color.decode("#c62828"));
		r.setFontSize(50.);

		// We create a second slide
		// We still use a layout. This time we use TITLE and CONTENT
		layout = defaultMaster.getLayout(SlideLayout.TITLE_AND_CONTENT);
		slide = ppt.createSlide(layout);

		// we clear the title
		title = slide.getPlaceholder(0);
		title.clearText();
		r = title.addNewTextParagraph().addNewTextRun();
		r.setText("Youtube Channel");

		// Adding a link
		XSLFHyperlink link = r.createHyperlink();
		link.setAddress("https://www.youtube.com/channel/UCkf8TccOAI2WPwNHs1ZeyJQ/videos");

		// we define some paragraphs for the slide
		XSLFTextShape content = slide.getPlaceholder(1);
		content.clearText();
		content.addNewTextParagraph().addNewTextRun().setText("Shrest is the best");
		content.addNewTextParagraph().addNewTextRun().setText("He made this presentation using java");
		content.addNewTextParagraph().addNewTextRun().setText("");

		// we create a third slide
		layout = defaultMaster.getLayout(SlideLayout.TITLE_AND_CONTENT);
		slide = ppt.createSlide(layout);
		title = slide.getPlaceholder(0);
		title.clearText();
		r = title.addNewTextParagraph().addNewTextRun();
		r.setText("some of his favourite foods:");

		content = slide.getPlaceholder(1);
		content.clearText();

		// we create a new paragraph
		p = content.addNewTextParagraph();
		p.setIndentLevel(0);

		// we define as a list
		p.setBullet(true);
		r = p.addNewTextRun();
		r.setText("CHICKEN,CAKE,CHIPS,FRENCH FRIES,CHEETOS,CHOCOLATE,");

		p = content.addNewTextParagraph();
		p.setIndentLevel(0);
		p.addNewTextRun().setText("JUICE,POPCORN,BANANA BREAD,TOAST,CHEESE,FISH,CHERRIES,");

		// more indentation
		p = content.addNewTextParagraph();
		p.setBulletAutoNumber(AutoNumberingScheme.alphaLcParenRight, 1);
		p.setIndentLevel(1);

		p.addNewTextRun().setText("AND MANY MORE...");
		slide = ppt.createSlide();
		byte[] pictureData = IOUtils.toByteArray(new FileInputStream(
				"C:\\Users\\shres\\Documents\\Shrest\\Pictures\\Quebec city and and aunt and uncle\\DSC08383.JPG"));

		XSLFPictureData pd = ppt.addPicture(pictureData, PictureData.PictureType.PNG);
		XSLFPictureShape picture = slide.createPicture(pd);
		picture.setAnchor(new Rectangle(320, 230, 100, 92));
		// now, we can save our presentation
		FileOutputStream out = new FileOutputStream(
				"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\PowerPoint.pptx");
		ppt.write(out);
		out.close();
		ppt.close();
	}

}