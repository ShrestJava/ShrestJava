package Files;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadDatFile {
	public static void main(String[] args) throws IOException {

		int count = 0;
		File file = new File("C:\\Users\\shres\\Documents\\dsc.dat");
		FileInputStream fis = new FileInputStream(file);
		byte[] bytesArray = new byte[(int) file.length()];
		fis.read(bytesArray);
		String s = new String(bytesArray);
		System.out.println(" " + new String(bytesArray));
	}
}