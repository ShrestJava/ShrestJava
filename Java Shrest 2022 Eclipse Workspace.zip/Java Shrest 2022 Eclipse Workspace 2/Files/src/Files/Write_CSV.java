package Files;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import com.opencsv.CSVWriter;

public class Write_CSV {

	public static void main(String[] args) throws IOException {
		CSVWriter csvWriter = new CSVWriter(new FileWriter(
				"C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\Java Created Files\\CSV FILE WRITTEN WITH JAVA.csv"));

		List<String[]> rows = new LinkedList<String[]>();
		rows.add(new String[] { "1", "Shrest", "123", "20" });
		rows.add(new String[] { "2", "Vineela", "456", "24" });
		rows.add(new String[] { "3", "Srinivas", "789", "18" });
		rows.add(new String[] { "4", "Ishanvi", "012", "28" });
		csvWriter.writeAll(rows);

		csvWriter.close();
	}
}