package Files;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;

public class System_Screenshot_Taker {
	static String path;

	public static void main(String[] args) throws AWTException, IOException {

		try {
			Thread.sleep(120);
			Robot r = new Robot();

			// It saves screenshot to desired path
			JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

			// invoke the showsSaveDialog function to show the save dialog
			int r1 = j.showSaveDialog(null);

			// if the user selects a file
			if (r1 == JFileChooser.APPROVE_OPTION)

			{
				// set the label to the path of the selected file
				path = j.getSelectedFile().getAbsolutePath();
			}

			// Used to get ScreenSize and capture image
			Rectangle capture = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage Image = r.createScreenCapture(capture);
			ImageIO.write(Image, "JPG", new File(path));
			System.out.println("Screenshot saved");

		} catch (AWTException | IOException | InterruptedException | NullPointerException ex) {

			System.out.println(ex);

		}

	}

}
