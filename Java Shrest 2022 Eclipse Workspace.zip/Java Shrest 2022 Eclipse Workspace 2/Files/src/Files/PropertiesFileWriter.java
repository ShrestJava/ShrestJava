package Files;

import java.io.FileWriter;
import java.util.Properties;

public class PropertiesFileWriter {
	public static void main(String[] args) throws Exception {

		Properties p = new Properties();
		p.setProperty("Name: ", "Shrestajna Burra");
		p.setProperty("Future Career: ", "Java Developer");

		p.store(new FileWriter(
				"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\PROPERTIES FILE WRITTEN WITH JAVA.properties"),
				"Shrest Details");

	}
}