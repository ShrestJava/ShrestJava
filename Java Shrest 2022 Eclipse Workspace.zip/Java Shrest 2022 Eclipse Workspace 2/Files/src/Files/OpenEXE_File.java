package Files;

public class OpenEXE_File {

	// This is Example that display how to run exe using java
	public static void main(String args[]) {
		// \"C:\\Windows\\WinSxS\\amd64_microsoft-windows-calc_31bf3856ad364e35_10.0.19041.1_none_5faf0ebeba197e78\\calc.exe\"
		// for calculator
		// C:/Windows/Notepad.exe for notepad
		String filePath = "C:\\Users\\shres\\Downloads\\mysql-installer-community-8.0.27.1.msi";
		try {

			Process p = Runtime.getRuntime().exec(filePath);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}