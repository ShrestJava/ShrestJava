package Files;

public class Test {
	public static void main(String[] args) {
		String workingDir = System.getProperty("user.dir");
		System.out.println(workingDir);
	}
}
