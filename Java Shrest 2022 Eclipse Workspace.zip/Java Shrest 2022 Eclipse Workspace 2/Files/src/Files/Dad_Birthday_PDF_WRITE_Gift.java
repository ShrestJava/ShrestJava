package Files;

import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class Dad_Birthday_PDF_WRITE_Gift {

	private static String FILE_PATH_NAME = "C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\PDF FILE WRITTEN WITH JAVA Dad Birthday.pdf";

	public static void main(String[] args) throws IOException {
		writeTextToPdfFile();
	}

	private static void writeTextToPdfFile() throws IOException {
		try (PDDocument doc = new PDDocument()) {

			/*
			 * Create a PDF Page: PDF Page 1 ->
			 */
			PDPage myPage = new PDPage();
			doc.addPage(myPage);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {

				cont.beginText();

				cont.setFont(PDType1Font.TIMES_BOLD, 48);
				cont.setLeading(15.5f);

				cont.newLineAtOffset(25, 700);
				String line1 = "Happy Birthday Dad!!!";

				cont.showText(line1);
				cont.newLine();
				cont.newLine();
				cont.newLine();
				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 32);
				String line2 = "47";
				cont.showText(line2);
				cont.newLine();
				cont.newLine();
				cont.newLine();

				String line3 = "YAY";
				cont.showText(line3);
				cont.newLine();

				cont.endText();
			}

			doc.save(FILE_PATH_NAME);

			/*
			 * Create a new PDF Page -> PDF Page 2:
			 */
			PDPage myPage2 = new PDPage();
			doc.addPage(myPage2);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage2)) {

				cont.beginText();

				cont.setLeading(15.5f);

				cont.newLineAtOffset(25, 700);
				cont.setFont(PDType1Font.TIMES_ROMAN, 12);

				cont.showText("DAD THE BEST ");
				cont.newLine();
				cont.newLine();
				cont.setFont(PDType1Font.TIMES_ROMAN, 18);
				cont.showText("HAVE FUN Playing My Game");
				cont.newLine();
				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 12);
				cont.showText("From Shrest");

				cont.newLine();

				cont.newLine();

				cont.endText();
			}

			doc.save(FILE_PATH_NAME);
			Snake hi = new Snake();
			hi.main(null);

			System.out.println("Done Creating PDF File(" + FILE_PATH_NAME + ")");
		}
	}
}