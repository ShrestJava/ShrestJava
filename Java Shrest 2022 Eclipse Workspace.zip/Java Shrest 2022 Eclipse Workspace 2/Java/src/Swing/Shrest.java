package Swing;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import com.toedter.calendar.JCalendar;

import Java.BMI;
import Java.Calander1;
import Java.Calculator2;
import Java.Notepad;
import Java.Snake;
import Java.SpreadSheet;

public class Shrest {

	public JFrame frame;
	private JTextField txtCm;
	private JTextField txtKg;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Shrest window = new Shrest();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Shrest() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 873, 516);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JButton btnNewButton = new JButton("Notepad");
		btnNewButton.setToolTipText("Open Notepad");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Notepad();
			}
		});

		JLabel lblNewLabel = new JLabel("Height:");

		JLabel lblNewLabel_1 = new JLabel("Weight:");

		txtCm = new JTextField();
		txtCm.setText("142.8 Cm");
		txtCm.setColumns(10);

		txtKg = new JTextField();
		txtKg.setText("36.4 Kg");
		txtKg.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Shrestajna Burra");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 21));

		JCalendar calendar = new JCalendar();

		JButton btnNewButton_1 = new JButton("Calculator");
		btnNewButton_1.setToolTipText("Open Calculator");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Calculator2();
			}
		});

		JButton btnNewButton_2 = new JButton("Shutdown");
		btnNewButton_2.setToolTipText("Shutdown computer");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Runtime rt = Runtime.getRuntime();
				try {
					Process pr = rt.exec("cmd /c shutdown -s"); // for shutdown
					// Process pr1=rt.exec("cmd /c shutdown -r"); // for restart
					// Process pr2=rt.exec("cmd /c shutdown -l"); // for log off
				} catch (Exception e) {

				}
			}
		});

		JButton btnNewButton_3 = new JButton("Spreadsheet");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SpreadSheet hi11 = new SpreadSheet();
				hi11.main(null);
			}
		});
		btnNewButton_3.setToolTipText("Open Spreadsheet");

		JButton btnNewButton_4 = new JButton("Log Out");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Runtime rt = Runtime.getRuntime();
				try {
					// Process pr = rt.exec("cmd /c shutdown -s"); // for shutdown
					// Process pr1=rt.exec("cmd /c shutdown -r"); // for restart
					Process pr2 = rt.exec("cmd /c shutdown -l"); // for log off
				} catch (Exception e) {

				}
			}

		});
		btnNewButton_4.setToolTipText("log out of computer");

		JSeparator separator = new JSeparator();

		JButton btnNewButton_5 = new JButton("BMI Calculation");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BMI hi = new BMI();
				hi.main(null);
			}
		});
		btnNewButton_5.setToolTipText("Calculate BMI");

		JButton btnNewButton_6 = new JButton("Snake Game");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Snake snake = new Snake();
				snake.main(null);
			}
		});
		btnNewButton_6.setToolTipText("Play Snake");

		JButton btnNewButton_7 = new JButton("Calendar");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Calander1 cal = new Calander1();
				cal.main(null);
			}
		});
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addGroup(groupLayout
				.createSequentialGroup()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup().addGap(19).addComponent(lblNewLabel_2,
								GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup().addGroup(groupLayout
								.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup().addContainerGap()
										.addComponent(btnNewButton).addGap(30).addComponent(btnNewButton_1))
								.addGroup(groupLayout.createSequentialGroup().addGap(18).addGroup(groupLayout
										.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup()
												.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
														.addComponent(lblNewLabel).addComponent(lblNewLabel_1))
												.addGap(1)
												.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
														.addComponent(txtKg, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
														.addComponent(txtCm, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
										.addGroup(groupLayout.createSequentialGroup().addComponent(btnNewButton_2)
												.addPreferredGap(ComponentPlacement.UNRELATED)
												.addComponent(btnNewButton_4, GroupLayout.PREFERRED_SIZE, 70,
														GroupLayout.PREFERRED_SIZE)))))
								.addGap(56)
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup().addComponent(btnNewButton_3)
												.addGap(29).addComponent(btnNewButton_5).addGap(18)
												.addComponent(btnNewButton_6))
										.addComponent(btnNewButton_7))
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(calendar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addGap(257)))
				.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup().addContainerGap()
						.addComponent(separator, GroupLayout.PREFERRED_SIZE, 831, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(206, Short.MAX_VALUE)));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup().addContainerGap()
				.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE).addComponent(btnNewButton)
										.addComponent(btnNewButton_1).addComponent(btnNewButton_3)
										.addComponent(btnNewButton_5).addComponent(btnNewButton_6))
								.addGap(18)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel)
										.addComponent(txtCm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(btnNewButton_7))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblNewLabel_1).addComponent(txtKg, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(calendar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE))
				.addGap(36)
				.addComponent(
						separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addGap(43)
				.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE).addComponent(btnNewButton_2)
						.addComponent(btnNewButton_4, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
				.addContainerGap(141, Short.MAX_VALUE)));
		frame.getContentPane().setLayout(groupLayout);
	}
}
