package Files;

import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class PDF_WRITE {

	private static String FILE_PATH_NAME = "C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\Java Created Files\\PDF FILE WRITTEN WITH JAVA.pdf";

	public static void main(String[] args) throws IOException {
		writeTextToPdfFile();
	}

	private static void writeTextToPdfFile() throws IOException {
		try (PDDocument doc = new PDDocument()) {

			/*
			 * Create a PDF Page: PDF Page 1 ->
			 */
			PDPage myPage = new PDPage();
			doc.addPage(myPage);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {

				cont.beginText();

				cont.setFont(PDType1Font.TIMES_BOLD, 48);
				cont.setLeading(15.5f);

				cont.newLineAtOffset(25, 700);
				String line1 = "SHREST THE BEST";

				cont.showText(line1);
				cont.newLine();
				cont.newLine();
				cont.newLine();
				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 32);
				String line2 = "is never a pest";
				cont.showText(line2);
				cont.newLine();
				cont.newLine();
				cont.newLine();

				String line3 = "shrest";
				cont.showText(line3);
				cont.newLine();

				cont.endText();
			}

			doc.save(FILE_PATH_NAME);

			/*
			 * Create a new PDF Page -> PDF Page 2:
			 */
			PDPage myPage2 = new PDPage();
			doc.addPage(myPage2);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage2)) {

				cont.beginText();

				cont.setLeading(15.5f);

				cont.newLineAtOffset(25, 700);
				cont.setFont(PDType1Font.TIMES_ROMAN, 12);

				// line 1 = "What does grokonez mean?"
				cont.showText("SHREST THE BEST ");
				cont.newLine();
				cont.newLine();
				cont.setFont(PDType1Font.TIMES_ROMAN, 18);
				cont.showText("shrest Is Very good and Shrest is smart");
				cont.newLine();
				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 12);
				cont.showText(
						"Shrest the best is never a pest so he went on a quest with the rest of the best and found the treasure chest so ");

				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 12);

				String line2 = "he was never depressed so he took a test to see if he was better than the rest. he found out he passed the test ";
				cont.showText(line2);
				cont.newLine();

				String line3 = "so he put on a vest and had a fest the he found a nest with a birdie guest so shrest put on crest to brush the best ";
				cont.showText(line3);
				cont.newLine();
				String line4 = "teeth so he was never stressed shrest went west on a gest and ate some zest and everyone was impressed";
				cont.showText(line4);
				cont.newLine();
				cont.newLine();

				cont.newLine();

				cont.newLine();

				cont.newLine();

				cont.setFont(PDType1Font.TIMES_ROMAN, 48);
				String line45 = "THAT'S SHREST!";
				cont.showText(line45);
				cont.newLine();

				cont.endText();
			}

			doc.save(FILE_PATH_NAME);

			System.out.println("Done!");
		}
	}
}