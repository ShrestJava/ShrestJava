package Files;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class OpenAnyFileUsingDefaultWindowsApplication {
	public static void main(String[] args) throws IOException {
		// put your file in the quotation marks below

		Desktop.getDesktop().open(new File(""));
	}
}
