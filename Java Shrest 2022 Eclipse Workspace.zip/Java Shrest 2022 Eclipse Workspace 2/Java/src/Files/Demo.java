package Files;

import javax.swing.UIManager;

public class Demo {
	public static void main(String args[]) throws Exception {

		UIManager.LookAndFeelInfo[] looks = UIManager.getInstalledLookAndFeels();
		for (UIManager.LookAndFeelInfo look : looks) {
			System.out.println(look.getClassName());
		}
	}
}
