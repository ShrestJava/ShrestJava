package Files;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;

public class CreatingJSONDocument {
	@SuppressWarnings({ "unchecked" })
	public static void main(String args[]) {
		// Creating a JSONObject object
		JSONObject jsonObject = new JSONObject();
		// Inserting key-value pairs into the json object
		jsonObject.put("ID", "1");
		jsonObject.put("First_Name", "Shrestajna");
		jsonObject.put("Last_Name", "Burra");
		jsonObject.put("Date_Of_Birth", "2010-11-14");
		jsonObject.put("Place_Of_Birth", "Toronto, Canada");
		jsonObject.put("Country", "Canada");
		JSONObject jsonObject1 = new JSONObject();
		// Inserting key-value pairs into the json object
		jsonObject1.put("ID", "2");
		jsonObject1.put("First_Name", "Ishanvi");
		jsonObject1.put("Last_Name", "Burra");
		jsonObject1.put("Date_Of_Birth", "2015-07-24");
		jsonObject1.put("Place_Of_Birth", "Calgary, Canada");
		jsonObject1.put("Country", "Canada");
		JSONObject jsonObject2 = new JSONObject();
		// Inserting key-value pairs into the json object
		jsonObject2.put("ID", "3");
		jsonObject2.put("First_Name", "Srinivas");
		jsonObject2.put("Last_Name", "Burra");
		jsonObject2.put("Date_Of_Birth", "1974-07-30");
		jsonObject2.put("Place_Of_Birth", "Poodur, India");
		jsonObject2.put("Country", "Canada");
		JSONObject jsonObject3 = new JSONObject();
		// Inserting key-value pairs into the json object
		jsonObject3.put("ID", "4");
		jsonObject3.put("First_Name", "Vineela");
		jsonObject3.put("Last_Name", "Tirumula");
		jsonObject3.put("Date_Of_Birth", "1981-1-23");
		jsonObject3.put("Place_Of_Birth", "Hyderabad, India");
		jsonObject3.put("Country", "Canada");
		try {
			FileWriter file = new FileWriter(
					"C:\\Users\\shres\\Documents\\Shrest\\Coding And Programming\\Java Created Files\\JSON FILE WRITTEN WITH JAVA2.json");
			file.write(jsonObject.toString() + "\n");
			file.write(jsonObject1.toString() + "\n");
			file.write(jsonObject2.toString() + "\n");
			file.write(jsonObject3.toString() + "\n");
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(
				"JSON file created:\n" + jsonObject + "\n" + jsonObject1 + "\n" + jsonObject2 + "\n" + jsonObject3);
	}
}