package Files;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GIF_Web_Viewer {
	public static void main(String[] args) throws MalformedURLException {

		//URL url = new URL("https://i.pinimg.com/originals/e6/32/85/e63285cbfabd350591fdeec4b64d01a0.gif");
		URL url = new URL("https://c.tenor.com/_dfb1Liqn1EAAAAi/cumple-a%C3%B1os.gif");
		Icon icon1 = new ImageIcon(url);

		
		JLabel label2 = new JLabel(icon1);
		
		JFrame f1 = new JFrame("Animation");
		f1.getContentPane().add(label2);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f1.pack();
		f1.setLocationRelativeTo(null);
		f1.setVisible(true);
	}
}