package Java;

import java.math.BigInteger;
import java.util.Scanner;

public class Bin2Dec {
	public static void main(String args[]) {
		System.out.println("Enter your Binary number");
		Scanner sc = new Scanner(System.in);
		BigInteger i = sc.nextBigInteger();
		String h = i.toString();
		System.out.println("Decimal: " + Integer.parseInt(h, 2));

	}
}