package Java;

public class PC_Lock_Restart_Shutdown {

	/**
	 * @param args
	 */

	/**
	 * @system args
	 */
	/**
	 * @programer_level-auto generated Advanced+
	 */
	public static void main(String[] args) {
		Runtime rt = Runtime.getRuntime();
		try {
			// Process pr=rt.exec("cmd /c shutdown -s"); // for shutdown
			// Process pr1=rt.exec("cmd /c shutdown -r"); // for restart
			Process pr2 = rt.exec("cmd /c shutdown -l"); // for log off
		} catch (Exception e) {

		}
	}

}
