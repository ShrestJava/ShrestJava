package Java;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UnsupportedLookAndFeelException;



public class LoginMenu implements ActionListener {
	private static JLabel Success;
	private static JButton b;
	private static JPasswordField pwdfield;
	private static JLabel passlbl;
	private static JTextField usertext;
	private static JLabel usrlabel;
	private static String sum;
	private static JPanel panel;
	private static JFrame frame;
	private static JTextField usertext1;

	public static void main(String[] args) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Shrest_Swing.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Shrest_Swing.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Shrest_Swing.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Shrest_Swing.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		sum = JOptionPane.showInputDialog("Enter Full Name:");

		JOptionPane.showMessageDialog(null, "Please Click \"Ok\" " + sum, "", JFrame.EXIT_ON_CLOSE);
		panel = new JPanel();
		frame = new JFrame("Please login to your account");
		frame.setSize(450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.add(panel);
		panel.setLayout(null);
		usrlabel = new JLabel("Username");
		usrlabel.setBounds(10, 20, 80, 25);
		panel.add(usrlabel);

		usertext = new JTextField(20);
		usertext.setBounds(100, 20, 165, 25);
		panel.add(usertext);

		passlbl = new JLabel("Password");
		passlbl.setBounds(10, 50, 80, 25);
		panel.add(passlbl);

		pwdfield = new JPasswordField(20);
		pwdfield.setBounds(100, 50, 165, 25);
		pwdfield.setEchoChar('�');
		panel.add(pwdfield);
		b = new JButton("Login");
		b.setBounds(10, 80, 80, 25);
		b.addActionListener(new LoginMenu());
		panel.add(b);

		Success = new JLabel("");
		Success.setBounds(10, 110, 600, 25);
		panel.add(Success);

		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		String user = usertext.getText();
		@SuppressWarnings("deprecation")
		String pwd = pwdfield.getText();

		if (user.equals("Shrest") && pwd.equals("shrest123") && sum.equals("Shrestajna Burra")) {
			Success.setText("Login Successful! " + sum);
Shrest_Swing sb = new Shrest_Swing();



	
		sb.main(null);
		}

		else if (user.equals("Ishanvi") && pwd.equals("ishanvi123") && sum.equals("Ishanvi Burra")) {
			Success.setText("Login Successful! " + sum);
			Ishanvi_Swing sb1 = new Ishanvi_Swing();

			sb1.main(null);

		}

		else if (user.equals("Vineela") && pwd.equals("vineela123") && sum.equals("Vineela Tirumula")) {
			Success.setText("Login Successful! " + sum);
			Vineela_Swing sb2 = new Vineela_Swing();

			sb2.main(null);
		}

		else if (user.equals("Srinivas") && pwd.equals("srinivas123") && sum.equals("Srinivas Burra")) {
			Success.setText("Login Successful! " + sum);

			Srinivas_Swing sb3 = new Srinivas_Swing();

		
			sb3.main(null);

		} else {
			Success.setText("Login Unsuccessful " + sum + " please try again or Create an Account Now.");
		}

	}

}
