package Java;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class InternetChecker {
	public static void main(String[] args) {

		try {
			URL url = new URL("https://www.google.com");
			URLConnection cnnctn = url.openConnection();
			cnnctn.connect();
			System.out.println("Internet is connected");
		} catch (MalformedURLException e) {
			System.out.println("Internet is not connected");
		} catch (IOException e1) {
			System.out.println("Internet is not connected");
		}
	}
}
