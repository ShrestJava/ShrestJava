package Java;

import javax.swing.JEditorPane;
import javax.swing.JFrame;

public class HTMLcode_runner {
	JFrame myFrame = null;

	public static void main(String[] a) {
		(new HTMLcode_runner()).test();
	}

	private void test() {
		myFrame = new JFrame("JEditorPane Test");
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setSize(170, 195);
		JEditorPane myPane = new JEditorPane();
		myPane.setContentType("text/html"); // change the �html � to "plain" for normal editing for ex:
											// myPane.setContentType("text/plain");
		myPane.setText("<script src=\"https://apps.elfsight.com/p/platform.js\" defer></script>\r\n"
				+ "<div class=\"elfsight-app-751d242c-3c48-4fbd-b7c1-a877998988bf\"></div>");

		myFrame.setContentPane(myPane);
		myFrame.setVisible(true);
	}
}
