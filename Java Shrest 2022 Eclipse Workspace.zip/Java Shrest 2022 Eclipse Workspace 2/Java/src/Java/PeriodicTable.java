package Java;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.WindowConstants;

import Java.ElementData.Element;

class ElementData {
	public static Element emptyElement = new Element();
	private static int TOTAL_ELEMENTS = 118;
	public static Element[] elements = new Element[TOTAL_ELEMENTS];

	static {
		int i;
		for (i = 0; i < TOTAL_ELEMENTS; ++i) {
			elements[i] = new Element();
			elements[i].atomicNumber = i + 1;
		}
		elements[0].name = "Hydrogen";
		elements[1].name = "Helium";
		elements[2].name = "Lithium";
		elements[3].name = "Beryllium";
		elements[4].name = "Boron";
		elements[5].name = "Carbon";
		elements[6].name = "Nitrogen";
		elements[7].name = "Oxygen";
		elements[8].name = "Flourine";
		elements[9].name = "Neon";
		elements[10].name = "Sodium";
		elements[11].name = "Magnesium";
		elements[12].name = "Aluminum";
		elements[13].name = "Silicon";
		elements[14].name = "Phosphorus";
		elements[15].name = "Sulfur";
		elements[16].name = "Chlorine";
		elements[17].name = "Argon";
		elements[18].name = "Potassium";
		elements[19].name = "Calcium";
		elements[20].name = "Scandium";
		elements[21].name = "Titanium";
		elements[22].name = "Vanadium";
		elements[23].name = "Chromium";
		elements[24].name = "Manganese";
		elements[25].name = "Iron";
		elements[26].name = "Cobalt";
		elements[27].name = "Nickel";
		elements[28].name = "Copper";
		elements[29].name = "Zinc";
		elements[30].name = "Gallium";
		elements[31].name = "Germanium";
		elements[32].name = "Arsenic";
		elements[33].name = "Selenium";
		elements[34].name = "Bromine";
		elements[35].name = "Krypton";
		elements[36].name = "Rubidium";
		elements[37].name = "Strontium";
		elements[38].name = "Yttrium";
		elements[39].name = "Zirconium";
		elements[40].name = "Niobium";
		elements[41].name = "Molybdenum";
		elements[42].name = "Technetium";
		elements[43].name = "Ruthenium";
		elements[44].name = "Rhodium";
		elements[45].name = "Palladium";
		elements[46].name = "Silver";
		elements[47].name = "Cadmium";
		elements[48].name = "Indium";
		elements[49].name = "Tin";
		elements[50].name = "Antimony";
		elements[51].name = "Tellurium";
		elements[52].name = "Iodine";
		elements[53].name = "Xenon";
		elements[54].name = "Caesium";
		elements[55].name = "Barium";
		elements[56].name = "Lanthanum";
		elements[57].name = "Cerium";
		elements[58].name = "Praseodymium";
		elements[59].name = "Neodymium";
		elements[60].name = "Prometheum";
		elements[61].name = "Samarium";
		elements[62].name = "Europium";
		elements[63].name = "Gadolinium";
		elements[64].name = "Terbium";
		elements[65].name = "Dysprosium";
		elements[66].name = "Holmium";
		elements[67].name = "Erbium";
		elements[68].name = "Thulium";
		elements[69].name = "Ytterbium";
		elements[70].name = "Lutetnium";
		elements[71].name = "Hafnium";
		elements[72].name = "Tantalum";
		elements[73].name = "Tungsten";
		elements[74].name = "Rhenium";
		elements[75].name = "Osmium";
		elements[76].name = "Iridium";
		elements[77].name = "Platinum";
		elements[78].name = "Gold";
		elements[79].name = "Mercury";
		elements[80].name = "Thallium";
		elements[81].name = "Lead";
		elements[82].name = "Bismuth";
		elements[83].name = "Polonium";
		elements[84].name = "Astatine";
		elements[85].name = "Radon";
		elements[86].name = "Francium";
		elements[87].name = "Radium";
		elements[88].name = "Actinium";
		elements[89].name = "Thorium";
		elements[90].name = "Protactium";
		elements[91].name = "Uranium";
		elements[92].name = "Neptunium";
		elements[93].name = "Plutonium";
		elements[94].name = "Americium";
		elements[95].name = "Curium";
		elements[96].name = "Berkelium";
		elements[97].name = "Californium";
		elements[98].name = "Einsteinium";
		elements[99].name = "Fermium";
		elements[100].name = "Mendelevium";
		elements[101].name = "Nobelium";
		elements[102].name = "Lawrencium";
		elements[103].name = "Rutherfordium";
		elements[104].name = "Dubnium";
		elements[105].name = "Seaborgium";
		elements[106].name = "Bohrium";
		elements[107].name = "Hassium";
		elements[108].name = "Meitnerium";
		elements[109].name = "Darmstadtium";
		elements[110].name = "Roentgenium";
		elements[111].name = "Copernicium";
		elements[112].name = "Ununtrium";
		elements[113].name = "Flevorium";
		elements[114].name = "Ununpentium";
		elements[115].name = "Livermorium";
		elements[116].name = "Ununseptium";
		elements[117].name = "Ununoctium";

		elements[0].symbol = "H";
		elements[1].symbol = "He";
		elements[2].symbol = "Li";
		elements[3].symbol = "Be";
		elements[4].symbol = "B";
		elements[5].symbol = "C";
		elements[6].symbol = "N";
		elements[7].symbol = "O";
		elements[8].symbol = "F";
		elements[9].symbol = "Ne";
		elements[10].symbol = "Na";
		elements[11].symbol = "Mg";
		elements[12].symbol = "Al";
		elements[13].symbol = "Si";
		elements[14].symbol = "P";
		elements[15].symbol = "S";
		elements[16].symbol = "Cl";
		elements[17].symbol = "Ar";
		elements[18].symbol = "K";
		elements[19].symbol = "Ca";
		elements[20].symbol = "Sc";
		elements[21].symbol = "Ti";
		elements[22].symbol = "V";
		elements[23].symbol = "Cr";
		elements[24].symbol = "Mn";
		elements[25].symbol = "Fe";
		elements[26].symbol = "Co";
		elements[27].symbol = "Ni";
		elements[28].symbol = "Cu";
		elements[29].symbol = "Zn";
		elements[30].symbol = "Ga";
		elements[31].symbol = "Ge";
		elements[32].symbol = "As";
		elements[33].symbol = "Se";
		elements[34].symbol = "Br";
		elements[35].symbol = "Kr";
		elements[36].symbol = "Rb";
		elements[37].symbol = "Sr";
		elements[38].symbol = "Y";
		elements[39].symbol = "Zr";
		elements[40].symbol = "Nb";
		elements[41].symbol = "Mo";
		elements[42].symbol = "Tc";
		elements[43].symbol = "Ru";
		elements[44].symbol = "Rh";
		elements[45].symbol = "Pd";
		elements[46].symbol = "Ag";
		elements[47].symbol = "Cd";
		elements[48].symbol = "In";
		elements[49].symbol = "Sn";
		elements[50].symbol = "Sb";
		elements[51].symbol = "Te";
		elements[52].symbol = "I";
		elements[53].symbol = "Xe";
		elements[54].symbol = "Cs";
		elements[55].symbol = "Ba";
		elements[56].symbol = "La";
		elements[57].symbol = "Ce";
		elements[58].symbol = "Pr";
		elements[59].symbol = "Nd";
		elements[60].symbol = "Pm";
		elements[61].symbol = "Sm";
		elements[62].symbol = "Eu";
		elements[63].symbol = "Gd";
		elements[64].symbol = "Tb";
		elements[65].symbol = "Dy";
		elements[66].symbol = "Ho";
		elements[67].symbol = "Er";
		elements[68].symbol = "Tm";
		elements[69].symbol = "Yb";
		elements[70].symbol = "Lu";
		elements[71].symbol = "Hf";
		elements[72].symbol = "Tb";
		elements[73].symbol = "W";
		elements[74].symbol = "Re";
		elements[75].symbol = "Os";
		elements[76].symbol = "Ir";
		elements[77].symbol = "Pt";
		elements[78].symbol = "Au";
		elements[79].symbol = "Hg";
		elements[80].symbol = "Tl";
		elements[81].symbol = "Pb";
		elements[82].symbol = "Bi";
		elements[83].symbol = "Po";
		elements[84].symbol = "At";
		elements[85].symbol = "Rn";
		elements[86].symbol = "Fr";
		elements[87].symbol = "Ra";
		elements[88].symbol = "Ac";
		elements[89].symbol = "Th";
		elements[90].symbol = "Pa";
		elements[91].symbol = "U";
		elements[92].symbol = "Np";
		elements[93].symbol = "Pu";
		elements[94].symbol = "Am";
		elements[95].symbol = "Cm";
		elements[96].symbol = "Bk";
		elements[97].symbol = "Cf";
		elements[98].symbol = "Es";
		elements[99].symbol = "Fm";
		elements[100].symbol = "Md";
		elements[101].symbol = "No";
		elements[102].symbol = "Lr";
		elements[103].symbol = "Rf";
		elements[104].symbol = "Db";
		elements[105].symbol = "Sg";
		elements[106].symbol = "Bh";
		elements[107].symbol = "Hs";
		elements[108].symbol = "Mt";
		elements[109].symbol = "Ds";
		elements[110].symbol = "Rg";
		elements[111].symbol = "Cn";
		elements[112].symbol = "Uut";
		elements[113].symbol = "Fl";
		elements[114].symbol = "Uup";
		elements[115].symbol = "Lv";
		elements[116].symbol = "Uus";
		elements[117].symbol = "Uuo";

		elements[0].metallicProperties = MetallicProperties.NON_METALLIC;
		elements[1].metallicProperties = MetallicProperties.NON_METALLIC;
		elements[2].metallicProperties = MetallicProperties.METALLIC;
		elements[3].metallicProperties = MetallicProperties.METALLIC;
		elements[4].metallicProperties = MetallicProperties.METALLOID;

		for (i = 5; i < 10; ++i)
			elements[i].metallicProperties = MetallicProperties.NON_METALLIC;

		for (i = 10; i < 13; ++i)
			elements[i].metallicProperties = MetallicProperties.METALLIC;

		elements[13].metallicProperties = MetallicProperties.METALLOID;

		for (i = 14; i < 18; ++i)
			elements[i].metallicProperties = MetallicProperties.NON_METALLIC;

		for (i = 18; i < 31; ++i)
			elements[i].metallicProperties = MetallicProperties.METALLIC;

		elements[31].metallicProperties = MetallicProperties.METALLOID;
		elements[32].metallicProperties = MetallicProperties.METALLOID;

		for (i = 33; i < 36; ++i)
			elements[i].metallicProperties = MetallicProperties.NON_METALLIC;

		for (i = 36; i < 50; ++i)
			elements[i].metallicProperties = MetallicProperties.METALLIC;

		elements[50].metallicProperties = MetallicProperties.METALLOID;
		elements[51].metallicProperties = MetallicProperties.METALLOID;
		elements[52].metallicProperties = MetallicProperties.NON_METALLIC;
		elements[53].metallicProperties = MetallicProperties.NON_METALLIC;

		for (i = 54; i < 83; ++i)
			elements[i].metallicProperties = MetallicProperties.METALLIC;

		elements[83].metallicProperties = MetallicProperties.METALLOID;
		elements[84].metallicProperties = MetallicProperties.NON_METALLIC;
		elements[85].metallicProperties = MetallicProperties.NON_METALLIC;

		for (i = 86; i < 116; ++i)
			elements[i].metallicProperties = MetallicProperties.METALLIC;

		elements[116].metallicProperties = MetallicProperties.NON_METALLIC;
		elements[117].metallicProperties = MetallicProperties.NON_METALLIC;

		elements[0].matterState = MatterState.GAS;
		elements[1].matterState = MatterState.GAS;

		for (i = 2; i < 6; ++i)
			elements[i].matterState = MatterState.SOLID;

		for (i = 6; i < 10; ++i)
			elements[i].matterState = MatterState.GAS;

		for (i = 10; i < 16; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[16].matterState = MatterState.GAS;
		elements[17].matterState = MatterState.GAS;

		for (i = 18; i < 34; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[34].matterState = MatterState.LIQUID;
		elements[35].matterState = MatterState.GAS;

		for (i = 36; i < 43; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[44].matterState = MatterState.SYNTHETIC;

		for (i = 45; i < 52; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[53].matterState = MatterState.GAS;

		for (i = 54; i < 78; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[79].matterState = MatterState.LIQUID;

		for (i = 80; i < 84; ++i)
			elements[i].matterState = MatterState.SOLID;

		elements[85].matterState = MatterState.GAS;

		for (i = 86; i < 91; ++i)
			elements[i].matterState = MatterState.SOLID;

		for (i = 92; i < 117; ++i)
			elements[i].matterState = MatterState.SYNTHETIC;

		elements[0].atomicMass = 1.0079;
		elements[1].atomicMass = 4.0026;
		elements[2].atomicMass = 6.941;
		elements[3].atomicMass = 9.0122;
		elements[4].atomicMass = 10.811;
		elements[5].atomicMass = 12.0107;
		elements[6].atomicMass = 14.0067;
		elements[7].atomicMass = 15.9994;
		elements[8].atomicMass = 18.9984;
		elements[9].atomicMass = 20.1787;
		elements[10].atomicMass = 22.9897;
		elements[11].atomicMass = 24.305;
		elements[12].atomicMass = 26.9815;
		elements[13].atomicMass = 28.0855;
		elements[14].atomicMass = 30.9738;
		elements[15].atomicMass = 32.065;
		elements[16].atomicMass = 35.453;
		elements[17].atomicMass = 39.948;
		elements[18].atomicMass = 39.0983;
		elements[19].atomicMass = 40.078;
		elements[20].atomicMass = 44.9559;
		elements[21].atomicMass = 47.867;
		elements[22].atomicMass = 50.9415;
		elements[23].atomicMass = 51.9961;
		elements[24].atomicMass = 54.938;
		elements[25].atomicMass = 55.845;
		elements[26].atomicMass = 58.9332;
		elements[27].atomicMass = 58.6934;
		elements[28].atomicMass = 63.546;
		elements[29].atomicMass = 65.39;
		elements[30].atomicMass = 69.723;
		elements[31].atomicMass = 72.64;
		elements[32].atomicMass = 74.9216;
		elements[33].atomicMass = 78.96;
		elements[34].atomicMass = 79.904;
		elements[35].atomicMass = 83.8;
		elements[36].atomicMass = 85.4678;
		elements[37].atomicMass = 87.62;
		elements[38].atomicMass = 88.9059;
		elements[39].atomicMass = 91.224;
		elements[40].atomicMass = 92.9064;
		elements[41].atomicMass = 95.94;
		elements[42].atomicMass = 98;
		elements[43].atomicMass = 101.07;
		elements[44].atomicMass = 102.9055;
		elements[45].atomicMass = 106.42;
		elements[46].atomicMass = 107.8682;
		elements[47].atomicMass = 112.411;
		elements[48].atomicMass = 114.818;
		elements[49].atomicMass = 118.71;
		elements[50].atomicMass = 121.76;
		elements[51].atomicMass = 127.6;
		elements[52].atomicMass = 126.9045;
		elements[53].atomicMass = 131.293;
		elements[54].atomicMass = 132.9055;
		elements[55].atomicMass = 137.327;
		elements[56].atomicMass = 138.9055;
		elements[57].atomicMass = 140.116;
		elements[58].atomicMass = 140.9077;
		elements[59].atomicMass = 144.24;
		elements[60].atomicMass = 145;
		elements[61].atomicMass = 150.36;
		elements[62].atomicMass = 151.964;
		elements[63].atomicMass = 157.25;
		elements[64].atomicMass = 158.9253;
		elements[65].atomicMass = 162.5;
		elements[66].atomicMass = 164.9303;
		elements[67].atomicMass = 167.259;
		elements[68].atomicMass = 168.9342;
		elements[69].atomicMass = 173.04;
		elements[70].atomicMass = 174.967;
		elements[71].atomicMass = 178.49;
		elements[72].atomicMass = 180.9479;
		elements[73].atomicMass = 183.84;
		elements[74].atomicMass = 186.207;
		elements[75].atomicMass = 190.23;
		elements[76].atomicMass = 192.217;
		elements[77].atomicMass = 195.078;
		elements[78].atomicMass = 196.9665;
		elements[79].atomicMass = 200.59;
		elements[80].atomicMass = 204.3833;
		elements[81].atomicMass = 207.2;
		elements[82].atomicMass = 208.9804;
		elements[83].atomicMass = 209;
		elements[84].atomicMass = 210;
		elements[85].atomicMass = 222;
		elements[86].atomicMass = 223;
		elements[87].atomicMass = 226;
		elements[88].atomicMass = 227;
		elements[89].atomicMass = 232.0831;
		elements[90].atomicMass = 231.3059;
		elements[91].atomicMass = 238.0289;
		elements[92].atomicMass = 237;
		elements[93].atomicMass = 244;
		elements[94].atomicMass = 243;
		elements[95].atomicMass = 247;
		elements[96].atomicMass = 247;
		elements[97].atomicMass = 251;
		elements[98].atomicMass = 252;
		elements[99].atomicMass = 257;
		elements[100].atomicMass = 258;
		elements[101].atomicMass = 259;
		elements[102].atomicMass = 262;
		elements[103].atomicMass = 267;
		elements[104].atomicMass = 268;
		elements[105].atomicMass = 271;
		elements[106].atomicMass = 272;
		elements[107].atomicMass = 270;
		elements[108].atomicMass = 276;
		elements[109].atomicMass = 281;
		elements[110].atomicMass = 280;
		elements[111].atomicMass = 285;
		elements[112].atomicMass = 284;
		elements[113].atomicMass = 289;
		elements[114].atomicMass = 288;
		elements[115].atomicMass = 293;
		elements[116].atomicMass = 294;
		elements[117].atomicMass = 294;
	}

	public static Element lookupElement(String property, String propertyType) {
		if (property == null || property.trim().length() == 0 || propertyType == null)
			return emptyElement;
		property = property.trim();
		if (propertyType.equals("Atomic #"))
			try {
				int atomicNumber = Integer.parseInt(property);
				if (atomicNumber < 1 || atomicNumber > TOTAL_ELEMENTS)
					return emptyElement;
				return elements[atomicNumber - 1];
			} catch (NumberFormatException ignored) {

			}

		for (Element element : elements)
			if (element.name.equalsIgnoreCase(property) && propertyType.equals("Name"))
				return element;
			else if (element.symbol.equalsIgnoreCase(property) && propertyType.equals("Symbol"))
				return element;
		if (propertyType.equals("Name")) {
			int smallestDistance = Integer.MAX_VALUE;
			Element closestElement = emptyElement;
			for (Element element : elements) {
				int distance = levenshteinDistance(element.name, property);
				if (distance < smallestDistance) {
					closestElement = element;
					smallestDistance = distance;
				}
			}
			return closestElement;
		}
		return emptyElement;
	}

	private static int levenshteinDistance(String string1, String string2) {
		if (string1 == null || string2 == null)
			return Integer.MAX_VALUE;
		string1 = string1.toLowerCase();
		string2 = string2.toLowerCase();
		int[] costs = new int[string2.length() + 1];
		for (int j = 0; j < costs.length; j++)
			costs[j] = j;
		for (int i = 1; i <= string1.length(); i++) {
			costs[0] = i;
			int nw = i - 1;
			for (int j = 1; j <= string2.length(); j++) {
				int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]),
						string1.charAt(i - 1) == string2.charAt(j - 1) ? nw : nw + 1);
				nw = costs[j];
				costs[j] = cj;
			}
		}
		return costs[string2.length()];
	}

	private static String getRealName(@SuppressWarnings("rawtypes") Enum e) {
		if (e.name().equals("NOT_APPLICABLE"))
			return "N/A";
		String name = e.name();
		return name.charAt(0) + name.substring(1, name.length()).toLowerCase().replaceAll("_", "-");
	}

	public enum MetallicProperties {
		NON_METALLIC, METALLOID, METALLIC, NOT_APPLICABLE;

		public String toString() {
			return getRealName(this);
		}
	}

	public enum MatterState {
		SOLID, LIQUID, GAS, SYNTHETIC, NOT_APPLICABLE;

		public String toString() {
			return getRealName(this);
		}
	}

	static class Element {
		public int atomicNumber = 0;
		public String name = "N/A";
		public String symbol = "N/A";
		public MetallicProperties metallicProperties = MetallicProperties.NOT_APPLICABLE;
		public MatterState matterState = MatterState.NOT_APPLICABLE;
		public double atomicMass = 0;
	}
}

class PeriodicFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8792974809184904855L;

	public PeriodicFrame() {
		super(" S H Re S Ta j Na Periodic Table");
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		try {

		} catch (Exception e) {
			e.printStackTrace();
		}
		JPanel inputPanel = new JPanel();
		final ButtonGroup propertyTypeOptions = new ButtonGroup();
		JRadioButton atomicNumberOptionButton = new JRadioButton("Atomic Number");
		propertyTypeOptions.add(atomicNumberOptionButton);
		inputPanel.add(atomicNumberOptionButton);
		JRadioButton nameOptionButton = new JRadioButton("Name");
		propertyTypeOptions.add(nameOptionButton);
		inputPanel.add(nameOptionButton);
		JRadioButton symbolOptionButton = new JRadioButton("Symbol");
		propertyTypeOptions.add(symbolOptionButton);
		inputPanel.add(symbolOptionButton);
		final JTextField propertyField = new JTextField(15);
		inputPanel.add(propertyField);
		this.add(inputPanel, "North");

		JButton lookupButton = new JButton("Search");
		this.add(lookupButton, "Center");

		JPanel outputPanel = new JPanel();
		outputPanel.setLayout(new BoxLayout(outputPanel, BoxLayout.Y_AXIS));
		final UneditableJTextPane atomicNumberTextPane = new UneditableJTextPane("Atomic #: ");
		outputPanel.add(atomicNumberTextPane);
		final UneditableJTextPane nameTextPane = new UneditableJTextPane("Name: ");
		outputPanel.add(nameTextPane);
		final UneditableJTextPane symbolTextPane = new UneditableJTextPane("Symbol: ");
		outputPanel.add(symbolTextPane);
		final UneditableJTextPane metallicPropertiesTextPane = new UneditableJTextPane("Metallic Properties: ");
		outputPanel.add(metallicPropertiesTextPane);
		final UneditableJTextPane matterStateTextPane = new UneditableJTextPane("Matter State: ");
		outputPanel.add(matterStateTextPane);
		final UneditableJTextPane atomicMassTextPane = new UneditableJTextPane("Atomic Mass: ");
		outputPanel.add(atomicMassTextPane);
		this.add(outputPanel, "South");

		lookupButton.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent e) {

			}

			public void mousePressed(MouseEvent e) {

			}

			public void mouseReleased(MouseEvent e) {
				String propertyType = "";
				Enumeration<AbstractButton> buttons = propertyTypeOptions.getElements();
				while (buttons.hasMoreElements()) {
					AbstractButton button = buttons.nextElement();
					if (button.isSelected())
						propertyType = button.getText();
				}
				if (propertyField.getText().trim().length() > 0 && !propertyType.equals("")) {
					Element element = ElementData.lookupElement(propertyField.getText(), propertyType);
					if (propertyType.equals("Name") && !propertyField.getText().equals(element.name)) {
						JOptionPane.showMessageDialog(PeriodicFrame.this,
								"Element not found.\nDid you mean to lookup " + element.name + '?', "Periodic Table",
								JOptionPane.INFORMATION_MESSAGE);
						element = ElementData.emptyElement;
					} else if (element == ElementData.emptyElement)
						JOptionPane.showMessageDialog(PeriodicFrame.this, "Element not found.", "Periodic Table",
								JOptionPane.INFORMATION_MESSAGE);
					atomicNumberTextPane.setText("Atomic #: " + element.atomicNumber);
					nameTextPane.setText("Name: " + element.name);
					symbolTextPane.setText("Symbol: " + element.symbol);
					metallicPropertiesTextPane.setText("Metallic Properties: " + element.metallicProperties);
					matterStateTextPane.setText("Matter State: " + element.matterState);
					atomicMassTextPane.setText("Atomic Mass: " + element.atomicMass);
				}
				PeriodicFrame.this.pack();
			}

			public void mouseEntered(MouseEvent e) {

			}

			public void mouseExited(MouseEvent e) {

			}
		});
		this.pack();
		this.setVisible(true);
	}
}

public class PeriodicTable {
	public static void main(String[] args) {
		new PeriodicFrame();
	}

}

class UneditableJTextPane extends JTextPane {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UneditableJTextPane(String text) {
		super();
		this.setText(text);
		this.setEditable(false);
	}
}
