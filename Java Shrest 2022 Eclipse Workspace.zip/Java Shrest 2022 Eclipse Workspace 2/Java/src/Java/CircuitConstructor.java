package Java;

import edu.colorado.phet.circuitconstructionkit.CircuitConstructionKitACApplication;

public class CircuitConstructor {
  public static void main(String[] args) {
	  CircuitConstructionKitACApplication cckaca = new CircuitConstructionKitACApplication(null);
	  cckaca.main(args);
}
}
