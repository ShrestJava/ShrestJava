package Java;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class Notepad extends JFrame implements ActionListener, ItemListener, MenuListener, KeyListener {

	FileOutputStream fos;
	FileInputStream fis;
	JFileChooser dialog;
	JOptionPane msgbox;
	boolean modified = true;
	String str;
	JMenuBar menubar;
	JMenu file, edit, help;
	JMenuItem nf, sf, of, exit, cut, copy, paste, about, selall, print;
	public JTextArea disp;
	JScrollPane scrollpane;

	public Notepad() {
		disp = new JTextArea();
		scrollpane = new JScrollPane(disp);// ,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		menubar = new JMenuBar();
		dialog = new JFileChooser();
		msgbox = new JOptionPane();
		file = new JMenu("File");
		file.setMnemonic('F');
		edit = new JMenu("Edit");
		edit.setMnemonic('E');
		help = new JMenu("Help");
		help.setMnemonic('H');
		nf = new JMenuItem("New");
		nf.setMnemonic('N');
		of = new JMenuItem("Open");
		of.setMnemonic('O');
		sf = new JMenuItem("Save");
		sf.setMnemonic('S');
		exit = new JMenuItem("Exit");
		exit.setMnemonic('x');
		cut = new JMenuItem("Cut");
		cut.setMnemonic('C');
		copy = new JMenuItem("Copy");
		copy.setMnemonic('o');
		paste = new JMenuItem("Paste");
		paste.setMnemonic('P');
		selall = new JMenuItem("Select All");
		selall.setMnemonic('A');
		print = new JMenuItem("Print");
		print.setMnemonic('r');

		about = new JMenuItem("About");
		about.setMnemonic('A');
		cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK, true));
		copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK, true));
		paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK, true));
		of.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK, true));
		sf.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK, true));

		about.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U, InputEvent.CTRL_MASK, true));

		file.add(nf);
		file.add(of);
		file.add(sf);
		file.addSeparator();
		file.add(exit);
		edit.add(cut);
		edit.add(copy);
		edit.add(paste);

		edit.addSeparator();
		edit.add(selall);
		edit.add(print);
		help.add(about);
		menubar.add(file);
		menubar.add(edit);
		menubar.add(help);
		Container c = getContentPane();
		getRootPane().setJMenuBar(menubar);
		c.add(scrollpane);
		setSize(500, 500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setTitle("Untitled - Notepad");
		sf.addActionListener(this);
		of.addActionListener(this);
		exit.addActionListener(this);
		cut.addActionListener(this);
		copy.addActionListener(this);
		paste.addActionListener(this);
		selall.addActionListener(this);
		print.addActionListener(this);
		nf.addActionListener(this);
		edit.addMenuListener(this);
		disp.addKeyListener(this);
		about.addActionListener(this);
	}

	public void keyPressed(KeyEvent e) {
		// System.out.println("Press");
	}

	public void keyReleased(KeyEvent e) {
		// System.out.println("Release");
	}

	public void keyTyped(KeyEvent e) {
		String str = KeyEvent.getKeyModifiersText(InputEvent.CTRL_MASK);
		if (!str.equals("Ctrl"))
			modified = true;
	}

	public void menuSelected(MenuEvent ml) {
		// System.out.println("Sele");
		if (ml.getSource() == edit) {
			if (disp.getSelectedText() == null) {
				cut.setEnabled(false);
				copy.setEnabled(false);
			} else {
				cut.setEnabled(true);
				copy.setEnabled(true);
			}
		}
	}

	public void menuDeselected(MenuEvent ml) {
		// JOptionPane.showMessageDialog(null,"Menu option deselected");
	}

	public void menuCanceled(MenuEvent ml) {
		// JOptionPane.showMessageDialog(null,"Menu option canceled");
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == sf) {
			if (getTitle().equals("Untitled - Notepad"))
				sf(0);
			else if (modified)
				sf(1);
		} else if (ae.getSource() == of) {
			int x;
			if (modified) {
				x = isModified();
				if (x == 1) {
					if (getTitle().equals("Untitled - Notepad"))
						sf(0);
					else
						sf(1);
					of();
				} else if (x != 3)
					of();
			} else
				of();
		} else if (ae.getSource() == exit) {
			int x;
			if (modified) {
				x = isModified();
				if (x == 1) {
					if (getTitle().equals("Untitled - Notepad"))
						sf(0);
					else
						sf(1);
				} else if (x == 2)
					System.exit(0);
			} else
				System.exit(0);
		} else if (ae.getSource() == nf) {
			int x;
			if (modified) {
				x = isModified();
				if (x == 1) {
					if (getTitle().equals("Untitled - Notepad"))
						sf(0);
					else
						sf(1);
				} else if (x != 3) {
					disp.setText("");
					setTitle("Untitled - Notepad");
					modified = false;
				}
			} else {
				disp.setText("");
				setTitle("Untitled - Notepad");
				modified = false;
			}
		} else if (ae.getSource() == cut) {
			disp.cut();
		} else if (ae.getSource() == copy) {
			disp.copy();

		}

		else if (ae.getSource() == paste) {
			disp.paste();
		}

		else if (ae.getSource() == selall) {
			disp.selectAll();

		} else if (ae.getSource() == about) {
			JOptionPane.showMessageDialog(null, "SBTech Made in 2020 made with java made by Shrestajna Burra");

		} else if (ae.getSource() == print) {
			try {
				disp.print();
			} catch (PrinterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void sf(int saveflag) {
		File f;
		try {
			if (saveflag == 0) {
				int x = dialog.showSaveDialog(this);
				if (x == 0) {
					f = dialog.getSelectedFile();
					fos = new FileOutputStream(f);
					setTitle(f.getPath());
					PrintStream ps = new PrintStream(fos);
					ps.print(disp.getText());
					modified = false;
				}
			} else {
				f = new File(getTitle());
				fos = new FileOutputStream(f);
				setTitle(f.getPath());
				PrintStream ps = new PrintStream(fos);
				ps.print(disp.getText());
				modified = false;
			}
		} catch (Exception e) {
		}
	}

	public void of() {
		int x = dialog.showOpenDialog(this);
		if (x == 0) {
			try {
				File f = dialog.getSelectedFile();
				fis = new FileInputStream(f);
				setTitle(f.getPath());
				disp.setText("");
				BufferedReader br = new BufferedReader(new InputStreamReader(fis));
				while ((str = br.readLine()) != null)
					disp.append(str + "\n");
				disp.replaceRange("", disp.getText().length() - 1, disp.getText().length());
				modified = false;
			} catch (Exception e) {
			}
		}
	}

	public int isModified() {
		int x = JOptionPane.showConfirmDialog(this,
				"The text in the " + getTitle() + " has changed\nDo you want to save it", "Notepad",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
		if (x == JOptionPane.YES_OPTION)
			return 1;
		else if (x == JOptionPane.NO_OPTION)
			return 2;
		else
			return 3;
	}

	public void itemStateChanged(ItemEvent itemevnt) {
	}

	public static void main(String[] args) {
		new Notepad();
	}
}
