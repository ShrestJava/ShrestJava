package Java;
import java.util.Locale;

import javax.speech.AudioException;
import javax.speech.Central;
import javax.speech.EngineException;
import javax.speech.EngineStateError;
import javax.speech.synthesis.Synthesizer;
import javax.speech.synthesis.SynthesizerModeDesc;

import Java.Snake;

public class Speak{
	Synthesizer synthesizer;
	public Speak(String phrase, int repeat) throws EngineException, AudioException, EngineStateError, IllegalArgumentException, InterruptedException {
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us" + ".cmu_us_kal.KevinVoiceDirectory");

		Central.registerEngineCentral("com.sun.speech.freetts" + ".jsapi.FreeTTSEngineCentral");

		synthesizer = Central.createSynthesizer(new SynthesizerModeDesc(Locale.US));

		synthesizer.allocate();
		synthesizer.resume();
		for(int i = 0; i<repeat; i++) {
			synthesizer.speakPlainText(phrase, null);
			// synthesizer.speakPlainText("hello world!", null);
		}
		synthesizer.waitEngineState(Synthesizer.QUEUE_EMPTY);

		// Deallocate the Synthesizer.
		synthesizer.deallocate();		
	}
	public static void main(String[] args) throws EngineException, AudioException, EngineStateError, IllegalArgumentException, InterruptedException {
		new Speak("aeim chaestanavu ishanvi nuuvo chaaala mean untavu!",1);
	}
}

