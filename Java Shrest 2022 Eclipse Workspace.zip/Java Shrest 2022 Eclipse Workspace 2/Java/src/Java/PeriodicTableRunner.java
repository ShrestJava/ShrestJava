package Java;

public class PeriodicTableRunner {
	public static void main(String[] args) {
		new PeriodicFrame();
	}
}
