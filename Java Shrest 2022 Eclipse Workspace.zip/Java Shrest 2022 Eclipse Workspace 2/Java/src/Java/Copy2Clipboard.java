package Java;

import java.awt.Toolkit;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;

public abstract class Copy2Clipboard implements ClipboardOwner {

	public static void setContents(String content) {
		try {
			StringSelection stringSelection = new StringSelection(content);
			java.awt.datatransfer.Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, stringSelection);
		} catch (Exception ignored) { // Ignore JDK crashes sorting data flavors.
		}
	}

	public static void main(String[] args) {
		setContents("shrest the best");
	}
}
