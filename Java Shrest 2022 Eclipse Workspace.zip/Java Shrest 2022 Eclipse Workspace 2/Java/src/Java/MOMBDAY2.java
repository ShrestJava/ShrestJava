package Java;


import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MOMBDAY2 {
	public static void main(String[] args) throws MalformedURLException {

		//URL url = new URL("https://i.pinimg.com/originals/e6/32/85/e63285cbfabd350591fdeec4b64d01a0.gif");
		URL url = new URL("https://c.tenor.com/_dfb1Liqn1EAAAAi/cumple-a%C3%B1os.gif");
		URL url2 = new URL("file:///C:/Users/shres/Documents/Shrest/Pictures/Video Camera/DSC00869 RESIZED.JPG");
		Icon icon = new ImageIcon(url2);
		Icon icon1 = new ImageIcon(url);

		JLabel label = new JLabel(icon);
		JLabel label2 = new JLabel(icon1);
		JFrame f = new JFrame("Animation");
		f.getContentPane().add(label);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		JFrame f1 = new JFrame("Animation");
		f1.getContentPane().add(label2);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f1.pack();
		f1.setLocationRelativeTo(null);
		f1.setVisible(true);
	}
}