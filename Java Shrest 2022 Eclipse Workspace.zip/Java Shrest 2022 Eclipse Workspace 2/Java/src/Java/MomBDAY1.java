package Java;

import javax.swing.UIManager;
import javax.swing.plaf.synth.SynthLookAndFeel;

public class MomBDAY1 {

	public static void main(String[] args) throws Exception {


		        System.out.println("HHHH     HHHH       AA         PPPPPPPPPPP  PPPPPPPPPPP      YY       YY ");
		        System.out.println("HHHH     HHHH       AA         PPPPPPPPPPP  PPPPPPPPPPP       YY     YY ");
		        System.out.println("HHHH     HHHH      AAAA        PP       PP  PP       PP        YY   YY ");
		        System.out.println("HHHH     HHHH     AA  AA       PP       PP  PP       PP         YY YY  ");
		        System.out.println("HHHHHHHHHHHHH    AA    AA      PPPPPPPPPPP  PPPPPPPPPPP           YY ");
		        System.out.println("HHHH     HHHH   AAAAAAAAAA     PP           PP                   YY ");
		        System.out.println("HHHH     HHHH  AA        AA    PP           PP                  YY ");
		        System.out.println("HHHH     HHHH AA          AA   PP           PP                 YY ");
                System.out.println("");
                System.out.println("");
                System.out.println("");
		        System.out.println("BBBBBBBBBBB  IIIIIIIIIIIII RRRRRRRRRRRR  TTTTTTTTTTTTTT HHHH       HHHH  DDDDDDDDDDD        AA        YY     YY ");
		        System.out.println("BB        BB      II       RR        RR        TT       HHHH       HHHH  DD         D      AAAA        YY   YY ");
		        System.out.println("BB        BB      II       RR       RR         TT       HHHH       HHHH  DD          D    AA  AA        YY YY ");
		        System.out.println("BBBBBBBBBB        II       RRRRRRRRRRR         TT       HHHHHHHHHHHHHHH  DD          D   AA    AA         YY ");
		        System.out.println("BB        BB      II       RR       RR         TT       HHHH       HHHH  DD          D  AAAAAAAAAA       YY ");
		        System.out.println("BB        BB      II       RR        RR        TT       HHHH       HHHH  DD         D  AA        AA     YY  ");
		        System.out.println("BBBBBBBBBBB  IIIIIIIIIIIII RR         RR       TT       HHHH       HHHH  DDDDDDDDDDD  AA          AA   YY ");
		        System.out.println("");
		        System.out.println("");
		        System.out.println("");
		        System.out.println("      M            M              OOOOOOO              M            M           !!!       ");
		        System.out.println("     MMM          MMM            OO     OO            MMM          MMM          !!!     ");
		        System.out.println("    MM MM        MM MM          OO       OO          MM MM        MM MM         !!!     ");
		        System.out.println("   MM   MM      MM   MM         OO       OO         MM   MM      MM   MM        !!!     ");
		        System.out.println("  MM     MM    MM     MM        OO       OO        MM     MM    MM     MM       !!!    ");
		        System.out.println(" MM       MM  MM       MM        OO     OO        MM       MM  MM       MM            ");
		        System.out.println("MM          MM          MM        OOOOOOO        MM          MM          MM     !!!       ");
		        System.out.println("");
		        System.out.println("");
		        System.out.println("");
		        System.out.println("                       ~~");
		        System.out.println("                       ||");
		        System.out.println("                       ||");
		        System.out.println("                 ~~~~~~~~~~~~~~~~~   ");
		        System.out.println("                |                 |");
		        System.out.println("                |                 |");
		        System.out.println("            ____|                 |___");
		        System.out.println("           |     `````````````````    |");
		        System.out.println("           |     Congratulations!     |");
		        System.out.println("     ______|                          |_____   ");
		        System.out.println("     |      ```````````````````````````     | ");
		        System.out.println("     |          Happy Birthday Mom!         | ");
		        System.out.println("     |______________________________________|    ");
		        System.out.println("");
		        System.out.println("");
		        System.out.println("");
		        System.out.println(" Happy Birthday! Many Many Happy Happy Returns Of The Day! ");

		    
		
		UIManager.setLookAndFeel(new SynthLookAndFeel());

	}

}