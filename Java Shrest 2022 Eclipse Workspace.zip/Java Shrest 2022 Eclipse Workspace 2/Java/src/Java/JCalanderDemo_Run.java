package Java;

import com.toedter.calendar.demo.JCalendarDemo;

public class JCalanderDemo_Run {
public static void main(String[] args) {
	JCalendarDemo j = new JCalendarDemo();
	j.main(null);
}
}
