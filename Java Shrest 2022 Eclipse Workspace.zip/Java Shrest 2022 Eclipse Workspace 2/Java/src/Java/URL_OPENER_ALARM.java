package Java;

import java.awt.AWTException;
import java.awt.Desktop;
import java.net.URI;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class URL_OPENER_ALARM {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws AWTException {
		// TODO Auto-generated method stub
		// List<Integer> list = new ArrayList<>();
		// for (int i = 1; i < 100; i++)

		// if( i % 2 != 0 ) {
		// {
		// list.add(i);
		// }
		// System.out.println(list);
//		int sum = 0;
		// for (Integer num : list) {
		/* System.out.println(num); */
		// sum += num;
		// }

		// System.out.println(sum);
		// /*System.out.println(i);*/

		// }

		System.out.println("Give in your name:");
		try (Scanner sc2 = new Scanner(System.in)) {
			String name = sc2.nextLine();

			System.out.println("Give in your url:");
			System.out
					.println("A great URL is https://www.w3schools.com/java/java_ref_keywords.asp it helps with java");
			try (Scanner sc21 = new Scanner(System.in)) {
				String hi = sc21.nextLine();
				System.out.println("Give in the time you want this url to open in seconds:");
				try (Scanner sc = new Scanner(System.in)) {
					int time = sc.nextInt();

					System.out.println("Alarm Scheduled.you can go do your work now " + name + ".");
					try {
						TimeUnit.SECONDS.sleep(time);
					} catch (InterruptedException e) {

					} finally {
						System.out.println("An error occured");
					}
					try {
						Desktop desktop = java.awt.Desktop.getDesktop();
						URI oURL = new URI(hi);
						desktop.browse(oURL);
					} catch (Exception e) {
						e.printStackTrace();
					}

				}

			}
		}
	}
}
