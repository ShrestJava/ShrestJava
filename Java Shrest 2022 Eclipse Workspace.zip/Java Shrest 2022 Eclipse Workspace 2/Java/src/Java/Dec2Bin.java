package Java;

import java.util.Scanner;

public class Dec2Bin {
	public static void main(String args[]) {
		int number;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a decimal number: ");
		number = sc.nextInt();
		System.out.println("Binary number is " + Integer.toString(number, 2));
	}
}