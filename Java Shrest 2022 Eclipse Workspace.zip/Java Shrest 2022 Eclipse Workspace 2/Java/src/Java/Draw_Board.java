package Java;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Draw_Board extends Frame implements MouseMotionListener {
	Draw_Board() {

		addMouseMotionListener(this);

		setSize(300, 300);
		setLayout(null);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
	}

	public void mouseDragged(MouseEvent e) {

		Graphics g = getGraphics();
		g.setColor(Color.BLACK);
		g.fillRect(e.getX(), e.getY(), 10, 10);
	}

	public void mouseMoved(MouseEvent e) {
	}

	public static void main(String[] args) {
		new Draw_Board();
	}
}
