package Java;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

public class RandomDayChooser {

	public static void main(String[] args) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
		ArrayList<String> days = new ArrayList<String>();
		for (int i = 0; i < 365; i++) {
			c.add(Calendar.DATE, 1);
			days.add(sdf.format(c.getTime()));

		}
		for (String day : days) {
			// System.out.println(day);
		}
		Random r = new Random();
		int shrest = r.nextInt(365);
		System.out.println("Corinavirus ending date on: " + days.get(shrest));

	}
}
