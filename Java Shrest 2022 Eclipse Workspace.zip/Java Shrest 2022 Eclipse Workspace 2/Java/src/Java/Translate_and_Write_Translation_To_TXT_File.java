package Java;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Translate_and_Write_Translation_To_TXT_File {
	static FileWriter writer;

	private static final String CLIENT_ID = "FREE_TRIAL_ACCOUNT";
	private static final String CLIENT_SECRET = "PUBLIC_SECRET";
	private static final String ENDPOINT = "http://api.whatsmate.net/v1/translation/translate";

	public static void main(String[] args) throws Exception {
// Translation requirements the list of language codes is specified in the bottom of the code
		String fromLang = "en";
		String toLang = "hi";
		String text = "Hello";

		Translate_and_Write_Translation_To_TXT_File.translate(fromLang, toLang, text);
	}

	public static void translate(String fromLang, String toLang, String text) throws Exception {
		// TODO: Should have used a 3rd party library to make a JSON string from an
		// object
		String jsonPayload = new StringBuilder().append("{").append("\"fromLang\":\"").append(fromLang).append("\",")
				.append("\"toLang\":\"").append(toLang).append("\",").append("\"text\":\"").append(text).append("\"")
				.append("}").toString();

		URL url = new URL(ENDPOINT);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("X-WM-CLIENT-ID", CLIENT_ID);
		conn.setRequestProperty("X-WM-CLIENT-SECRET", CLIENT_SECRET);
		conn.setRequestProperty("Content-Type", "application/json");

		OutputStream os = conn.getOutputStream();
		os.write(jsonPayload.getBytes());
		os.flush();
		os.close();

		int statusCode = conn.getResponseCode();
		System.out.println("Status Code: " + statusCode);
		BufferedReader br = new BufferedReader(
				new InputStreamReader((statusCode == 200) ? conn.getInputStream() : conn.getErrorStream()));
		String output;
		while ((output = br.readLine()) != null) {
			writer = new FileWriter("C:\\Users\\shres\\Desktop\\Translation.txt", true);
			writer.write(output);

		}
		writer.close();
		conn.disconnect();
	}

}

/*
 * { "af": "Afrikaans", "ar": "Arabic", "az": "Azerbaijani", "be": "Belarusian",
 * "bg": "Bulgarian", "bn": "Bengali", "bs": "Bosnian", "ca": "Catalan", "ceb":
 * "Cebuano", "cs": "Czech", "cy": "Welsh", "da": "Danish", "de": "German",
 * "el": "Greek", "en": "English", "eo": "Esperanto", "es": "Spanish", "et":
 * "Estonian", "eu": "Basque", "fa": "Persian", "fi": "Finnish", "fr": "French",
 * "ga": "Irish", "gl": "Galician", "gu": "Gujarati", "ha": "Hausa", "hi":
 * "Hindi", "hmn": "Hmong", "hr": "Croatian", "ht": "Haitian Creole", "hu":
 * "Hungarian", "hy": "Armenian", "id": "Indonesian", "ig": "Igbo", "is":
 * "Icelandic", "it": "Italian", "iw": "Hebrew", "ja": "Japanese", "jw":
 * "Javanese", "ka": "Georgian", "kk": "Kazakh", "km": "Khmer", "kn": "Kannada",
 * "ko": "Korean", "la": "Latin", "lo": "Lao", "lt": "Lithuanian", "lv":
 * "Latvian", "ma": "Punjabi", "mg": "Malagasy", "mi": "Maori", "mk":
 * "Macedonian", "ml": "Malayalam", "mn": "Mongolian", "mr": "Marathi", "ms":
 * "Malay", "mt": "Maltese", "my": "Myanmar (Burmese)", "ne": "Nepali", "nl":
 * "Dutch", "no": "Norwegian", "ny": "Chichewa", "pl": "Polish", "pt":
 * "Portuguese", "ro": "Romanian", "ru": "Russian", "si": "Sinhala", "sk":
 * "Slovak", "sl": "Slovenian", "so": "Somali", "sq": "Albanian", "sr":
 * "Serbian", "st": "Sesotho", "su": "Sudanese", "sv": "Swedish", "sw":
 * "Swahili", "ta": "Tamil", "te": "Telugu", "tg": "Tajik", "th": "Thai", "tl":
 * "Filipino", "tr": "Turkish", "uk": "Ukrainian", "ur": "Urdu", "uz": "Uzbek",
 * "vi": "Vietnamese", "yi": "Yiddish", "yo": "Yoruba", "zh-CN":
 * "Chinese Simplified", "zh-TW": "Chinese Traditional", "zu": "Zulu" }
 */