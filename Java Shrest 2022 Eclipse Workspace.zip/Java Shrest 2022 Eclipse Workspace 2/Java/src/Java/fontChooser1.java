package Java;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class fontChooser1 extends JFrame/* implements ActionListener,ItemListener,MenuListener,KeyListener */
{

	private JLabel sampleText = new JLabel("Label");

	private JComboBox fontComboBox;

	private JComboBox sizeComboBox;

	private JCheckBox boldCheck, italCheck;

	private String[] fonts;

	@SuppressWarnings("unchecked")
	public fontChooser1() {
		this.setSize(500, 150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		FontListener fl = new FontListener();
		this.add(sampleText, BorderLayout.NORTH);
		GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
		fonts = g.getAvailableFontFamilyNames();

		JPanel controlPanel = new JPanel();
		fontComboBox = new JComboBox(fonts);
		fontComboBox.addActionListener(fl);
		controlPanel.add(new JLabel("Family: "));
		controlPanel.add(fontComboBox);

		Integer[] sizes = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 12, 22, 24, 26, 28, 30,
				32, 40, 42, 48, 50, 54, 56, 60, 62, 64, 68, 70, 72, 76, 80, 82, 84, 86, 90, 94, 96, 98, 100, 102, 108,
				115, 120, 124, 125, 132, 136, 140, 148, 156, 164, 170, 172, 184, 196, 202, 204, 212, 216, 218, 240, 250,
				268, 300, 400, 500, 600, 700, 800, 900, 980, 1000, 1200, 1600, 1800, 2000, 4000, 6000, 8000, 12000 };

		sizeComboBox = new JComboBox(sizes);
		sizeComboBox.setSelectedIndex(5);
		sizeComboBox.addActionListener(fl);
		controlPanel.add(new JLabel("Size: "));
		controlPanel.add(sizeComboBox);

		boldCheck = new JCheckBox("Bold");
		boldCheck.addActionListener(fl);
		controlPanel.add(boldCheck);

		italCheck = new JCheckBox("Ital");
		italCheck.addActionListener(fl);
		controlPanel.add(italCheck);

		this.add(controlPanel, BorderLayout.SOUTH);
		fl.updateText();

		this.setVisible(true);
	}

	class FontListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			updateText();
		}

		public void updateText() {
			String name = (String) fontComboBox.getSelectedItem();

			Integer size = (Integer) sizeComboBox.getSelectedItem();

			int style;
			if (boldCheck.isSelected() && italCheck.isSelected())
				style = Font.BOLD | Font.ITALIC;
			else if (boldCheck.isSelected())
				style = Font.BOLD;
			else if (italCheck.isSelected())
				style = Font.ITALIC;
			else
				style = Font.PLAIN;

			Font f = new Font(name, style, size.intValue());
			sampleText.setFont(f);
		}
	}

	public static void main(String[] args) {

		new fontChooser1();

	}
}
