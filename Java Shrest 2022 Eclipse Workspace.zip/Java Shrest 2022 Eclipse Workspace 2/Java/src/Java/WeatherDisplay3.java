package Java;

import javax.swing.JEditorPane;
import javax.swing.JFrame;

public class WeatherDisplay3 {
	JFrame myFrame = null;

	public static void main(String[] a) {
		(new WeatherDisplay3()).test();
	}

	private void test() {
		myFrame = new JFrame("Weather");
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setSize(310, 214);
		JEditorPane myPane = new JEditorPane();
		myPane.setContentType("text/html"); // change the �html � to "plain" for normal editing for ex:
											// myPane.setContentType("text/plain");
		myPane.setText(
				"<!-- weather widget start --><a target=\"_blank\" href=\"https://www.booked.net/weather/montreal-30575\"><img src=\"https://w.bookcdn.com/weather/picture/3_30575_1_1_137AE9_287_ffffff_333333_08488D_1_ffffff_333333_0_6.png?scode=2&domid=w209&anc_id=29586\"  alt=\"booked.net\"/></a><!-- weather widget end -->");

		myFrame.setContentPane(myPane);
		myFrame.setVisible(true);
	}
}
