package Java;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

class OnlineTest extends JFrame implements ActionListener {
	JLabel l;
	JRadioButton jb[] = new JRadioButton[5];
	JButton b1, b2;
	ButtonGroup bg;
	int count = 0, current = 0, x = 1, y = 1, now = 0;
	int m[] = new int[10];

	OnlineTest(String s) {
		super(s);
		l = new JLabel();
		add(l);
		bg = new ButtonGroup();
		for (int i = 0; i < 5; i++) {
			jb[i] = new JRadioButton();
			add(jb[i]);
			bg.add(jb[i]);
		}
		b1 = new JButton("Next");
		b2 = new JButton("Bookmark");
		b1.addActionListener(this);
		b2.addActionListener(this);
		add(b1);
		add(b2);
		set();
		l.setBounds(30, 40, 450, 20);
		jb[0].setBounds(50, 80, 100, 20);
		jb[1].setBounds(50, 110, 100, 20);
		jb[2].setBounds(50, 140, 100, 20);
		jb[3].setBounds(50, 170, 100, 20);
		b1.setBounds(100, 240, 100, 30);
		b2.setBounds(270, 240, 100, 30);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setLocation(250, 100);
		setVisible(true);
		setSize(600, 350);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			if (check())
				count = count + 1;
			current++;
			set();
			if (current == 9) {
				b1.setEnabled(false);
				b2.setText("Result");
			}
		}
		if (e.getActionCommand().equals("Bookmark")) {
			JButton bk = new JButton("Bookmark" + x);
			bk.setBounds(480, 20 + 30 * x, 100, 30);
			add(bk);
			bk.addActionListener(this);
			m[x] = current;
			x++;
			current++;
			set();
			if (current == 9)
				b2.setText("Result");
			setVisible(false);
			setVisible(true);
		}
		for (int i = 0, y = 1; i < x; i++, y++) {
			if (e.getActionCommand().equals("Bookmark" + y)) {
				if (check())
					count = count + 1;
				now = current;
				current = m[y];
				set();
				((JButton) e.getSource()).setEnabled(false);
				current = now;
			}
		}

		if (e.getActionCommand().equals("Result")) {
			if (check())
				count = count + 1;
			current++;
			// System.out.println("correct ans="+count);
			JOptionPane.showMessageDialog(this, "results�:" + count + "/10");
			System.exit(0);
		}
	}

	void set() {
		jb[4].setSelected(true);
		if (current == 0) {
			l.setText("24+14");
			jb[0].setText("56");
			jb[1].setText("38");
			jb[2].setText("37");
			jb[3].setText("338");
		}
		if (current == 1) {
			l.setText("15+34");
			jb[0].setText("46");
			jb[1].setText("39");
			jb[2].setText("49");
			jb[3].setText("54");
		}
		if (current == 2) {
			l.setText("35+58");
			jb[0].setText("132");
			jb[1].setText("39");
			jb[2].setText("89");
			jb[3].setText("93");
		}
		if (current == 3) {
			l.setText("67+78");
			jb[0].setText("145");
			jb[1].setText("154");
			jb[2].setText("549");
			jb[3].setText("1435");
		}
		if (current == 4) {
			l.setText("124+364");
			jb[0].setText("3789");
			jb[1].setText("886");
			jb[2].setText("488");
			jb[3].setText("364");
		}
		if (current == 5) {
			l.setText("567+345");
			jb[0].setText("5466");
			jb[1].setText("218");
			jb[2].setText("912");
			jb[3].setText("921");
		}
		if (current == 6) {
			l.setText("657+945");
			jb[0].setText("2752");
			jb[1].setText("1572");
			jb[2].setText("1567");
			jb[3].setText("1527");
		}
		if (current == 7) {
			l.setText("1367+8747");
			jb[0].setText("10411");
			jb[1].setText("453534");
			jb[2].setText("7438");
			jb[3].setText("10114");
		}
		if (current == 8) {
			l.setText("56094+78654");
			jb[0].setText("3542343");
			jb[1].setText("134748");
			jb[2].setText("134784");
			jb[3].setText("43543");
		}
		if (current == 9) {
			l.setText("887877+63777");
			jb[0].setText("951645");
			jb[1].setText("43532432");
			jb[2].setText("951654");
			jb[3].setText("54324324");
		}
		l.setBounds(30, 40, 450, 20);
		for (int i = 0, j = 0; i <= 90; i += 30, j++)
			jb[j].setBounds(50, 80 + i, 200, 20);
	}

	boolean check() {
		if (current == 0)
			return (jb[1].isSelected());
		if (current == 1)
			return (jb[2].isSelected());
		if (current == 2)
			return (jb[3].isSelected());
		if (current == 3)
			return (jb[0].isSelected());
		if (current == 4)
			return (jb[2].isSelected());
		if (current == 5)
			return (jb[2].isSelected());
		if (current == 6)
			return (jb[1].isSelected());
		if (current == 7)
			return (jb[3].isSelected());
		if (current == 8)
			return (jb[1].isSelected());
		if (current == 9)
			return (jb[2].isSelected());
		return false;
	}
}

public class Java_Quiz {

	public static void main(String s[]) {
		new OnlineTest("Java Test");
	}

}
