package Java;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class SetVolumeAndOtherCoolNirCmdCommands {

	public static void setSystemVolume(int volume) throws IOException
	{
	    if(volume < 0 || volume > 100)
	    {
	        throw new RuntimeException("Error: " + volume + " is not a valid number. Choose a number between 0 and 100");
	    }

	    else
	    { 
	    	// this is because 100% is 65535 and the lowest (0%) is 0
	        double endVolume = 655.35 * volume;

	        Runtime rt = Runtime.getRuntime();
	        Process pr;
	       
	           // pr = rt.exec("nircmd.exe" + " setsysvolume " + endVolume); set volume (out of 65535 but we did the division to make it easier!)
	          //  pr = rt.exec("nircmd.exe" + " mutesysvolume 0");// unmute
	             //pr = rt.exec("nircmd.exe" + " mutesysvolume 1"); //mute
	       //  pr = rt.exec("nircmd.exe" + " speak text \"Shrest the best is never a pest so he went on a quest with the rest of the best and found the treasure chest so he was never depressed so he took a test to see if he was better than the rest. he found out he passed the test so he put on a vest and had a fest the he found a nest with a birdie guest so shrest put on crest to brush the best teeth so he was never stressed so shrest went west on a gest and ate some zest and everyone was impressed because shrest is blessed...... And Thats Shrest!!!!\""); // converts text to speech (Shrest the best is never a pest so he went on a quest with the rest of the best and found the treasure chest so he was never depressed so he took a test to see if he was better than the rest. he found out he passed the test so he put on a vest and had a fest the he found a nest with a birdie guest so shrest put on crest to brush the best teeth so he was never stressed so shrest went west on a gest and ate some zest and everyone was impressed because shrest is blessed...... And Thats Shrest!!!!)
	        // pr = rt.exec("nircmd.exe" + " cmdshortcut \"~$folder.desktop$\" \"Say the best word!\"        speak text \"Shrest the best is never a pest so he went on a quest with the rest of the best and found the treasure chest so he was never depressed so he took a test to see if he was better than the rest. he found out he passed the test so he put on a vest and had a fest the he found a nest with a birdie guest so shrest put on crest to brush the best teeth so he was never stressed so shrest went west on a gest and ate some zest and everyone was impressed because shrest is blessed...... And Thats Shrest!!!!\""); // creates a desktop shortcut that converts text to speech (Shrest the best is never a pest so he went on a quest with the rest of the best and found the treasure chest so he was never depressed so he took a test to see if he was better than the rest. he found out he passed the test so he put on a vest and had a fest the he found a nest with a birdie guest so shrest put on crest to brush the best teeth so he was never stressed so shrest went west on a gest and ate some zest and everyone was impressed because shrest is blessed...... And Thats Shrest!!!!)

	         // pr = rt.exec("nircmd.exe" + " speak file \"C:\\users\\shres\\Documents\\New Text Document.txt\" 0 100 \"C:\\users\\shres\\Documents\\Speech.wav\" 48kHz16BitStereo"); // takes in a txt file and creates a wav file with the tsxt to speech! (Converts New Text Document.txt into Speech.wav) * this doesn't overwrite the text file 
	         // pr = rt.exec("nircmd.exe" + " cmdshortcut \"~$folder.desktop$\" \"Switch Mute Setting\" mutesysvolume 2"); // Create a shortcut on your desktop that switch the system volume between the mute and normal state.
	        //	pr = rt.exec("nircmd.exe" + " nircmd.exe qboxcom \"Do you want to reboot ?\" \"question\" exitwin reboot"); // prompts you a yes/no dialog if yes is chosen, system restarts
	        	// pr = rt.exec("nircmd.exe" + " exitwin poweroff"); // shutdown pc
	            //   pr = rt.exec("nircmd.exe " + "cmdwait 2000 savescreenshot \"C:\\Users\\shres\\Documents\\ScreenShot.png\"");
	        	//  pr = rt.exec("nircmd.exe" + " urlshortcut \"http://www.nirsoft.net\" \"~$folder.desktop$\" \"NirSoft\""); // creates a shortcut on desktop that opens norsoft.com
                  // for more things, go to https://www.nirsoft.net/utils/nircmd.html and remember to use Eclipse IDE and put a space before command and add nircmd.exe to your windows directory. nircmd.exe is located in Shrest\Coding And Programming	        	 
	   
	
	    }
	}
public static void main(String[] args) throws IOException {
setSystemVolume(19);
	
}
}
