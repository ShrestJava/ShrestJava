package Java;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class AutoClicker {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws AWTException {
		// TODO Auto-generated method stub
		List<Integer> list = new ArrayList<>();
		// for (int i = 1; i < 100; i++)

		// if( i % 2 != 0 ) {
		{
			// list.add(i);
			// }
			// System.out.println(list);
//			int sum = 0;
			// for (Integer num : list) {
			/* System.out.println(num); */
			// sum += num;
			// }

			// System.out.println(sum);
			// /*System.out.println(i);*/

			Scanner l = new Scanner(System.in);
			System.out.print("Enter the number of seconds in you want this auto clicker to start clicking:");
			int o = l.nextInt();

			Scanner j = new Scanner(System.in);
			System.out.print("Enter your cooardinates in _x,y_ format:");
			String n = j.nextLine();
			Scanner j1 = new Scanner(System.in);
			System.out.print("enter how many repeats you want:");
			int p = j1.nextInt();

			String v = n.substring(0, 4);
			String g = n.substring(6, 9);
			int x = Integer.parseInt(v);
			int y = Integer.parseInt(g);
			try {
				TimeUnit.SECONDS.sleep(o);
			} catch (InterruptedException e) {

			}
			for (int i = 0; i < p; i++) {
				Robot r = new Robot();
				r.mouseMove(x, y);
				r.mousePress(InputEvent.BUTTON1_MASK);
				r.mouseRelease(InputEvent.BUTTON1_MASK);
			}

		}
	}

}
//This is a auto clicker it clicks on its own. it simulates a mouse 
// this program works if you give in right coordinates
