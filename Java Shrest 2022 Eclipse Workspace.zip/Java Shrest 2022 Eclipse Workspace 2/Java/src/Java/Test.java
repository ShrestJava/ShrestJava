package Java;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestDemo jb = new TestDemo();
		jb.main(args);
	}

}
