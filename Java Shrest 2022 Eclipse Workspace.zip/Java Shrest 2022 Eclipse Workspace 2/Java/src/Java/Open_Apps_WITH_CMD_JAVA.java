package Java;

import java.io.IOException;

public class Open_Apps_WITH_CMD_JAVA {

	public static void main(String[] args) throws IOException {
		// "cmd.exe /C start microsoft-edge:" For Opening Edge
		// "cmd.exe /C start calc" For Opening Calculator
		// "cmd.exe /C start notepad" to open Notepad
		// "cmd.exe /C start charmap" to open special charactar map
		// "cmd.exe /C start mspaint" to open microsoft paint
		// "cmd.exe /C start wmplayer" to open windows media player
		// "cmd.exe /C start taskmgr" to open task manager
		// "cmd.exe /C start cmd" to open cmd
		// "cmd.exe /C start msedge www.google.com" For Opening Edge
		// use these links for more commands remember to put "cmd.exe /C " in front
		// |||||||
		// Links:https://www.tenforums.com/tutorials/78108-app-commands-list-windows-10-a.html
		// and https://www.ionos.com/digitalguide/server/know-how/windows-cmd-commands/

		// Enter Codes in the quotation marks below
		Runtime.getRuntime().exec("");
	}
}