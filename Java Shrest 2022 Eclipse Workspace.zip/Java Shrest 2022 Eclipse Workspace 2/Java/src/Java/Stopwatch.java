package Java;

import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Stopwatch {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		JFrame f = new JFrame("label");

		// create a label to display text
		JLabel l = new JLabel();

		// add text to label

		// create a panel
		JPanel p = new JPanel();

		// add label to panel
		p.add(l);

		// add panel to frame
		f.add(p);

		// set the size of frame
		f.setSize(300, 300);

		f.show();

		boolean x = true;
		long displayMinutes = 00;
		long starttime = System.currentTimeMillis();
		System.out.println("Timer:");
		while (x) {
			TimeUnit.SECONDS.sleep(1);
			long timepassed = System.currentTimeMillis() - starttime;
			long secondspassed = timepassed / 1000;
			if (secondspassed == 60) {
				secondspassed = 0;
				starttime = System.currentTimeMillis();
			}
			if ((secondspassed % 60) == 0)
				displayMinutes++;
			l.setSize(100, 100);
			l.setText(displayMinutes + ":" + secondspassed);
		}
	}
}
