package Java;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.WindowConstants;

public class Clock extends JFrame implements ActionListener {

	private int hi = 19;
	private final JLabel timeLabel = new JLabel();
	private final DateFormat df = new SimpleDateFormat("   " + "dd.MM.yyyy HH:mm:ss");

	public Clock() {
		timeLabel.setFont(new Font("Terminator Two", Font.PLAIN, 36));
		setLayout(new BorderLayout());
		add(timeLabel, BorderLayout.CENTER);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize(500, 300);
		new Timer(500, this).start();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new Clock().setVisible(true));
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		timeLabel.setText(df.format(new Date()));
	}

	public int getHi() {
		return hi;
	}

	public void setHi(int hi) {
		this.hi = hi;
	}
}