package Java;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

public class PlaySound {

	public static void main(String args[]) throws Error, Exception {
		PlayAudio();

	}

	private static void PlayAudio() {
		byte[] buf = new byte[1];

		AudioFormat af = new AudioFormat((float) 44100, 8, 1, true, false);
		SourceDataLine sdl = null;
		try {
			sdl = AudioSystem.getSourceDataLine(af);
		} catch (LineUnavailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sdl.open();
		} catch (LineUnavailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sdl.start();
		for (int i = 1; i < 1000 * (float) 44100 / 1000; i++) {
			// The Hertz is set to 540
			double angle = i / ((float) 44100 / 540) * 2.0 * Math.PI;
			buf[0] = (byte) (Math.sin(angle) * 100);
			sdl.write(buf, 0, 1);
		}
		sdl.drain();
		sdl.stop();

	}
}