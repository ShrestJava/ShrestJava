package Java;

import javax.swing.JEditorPane;
import javax.swing.JFrame;

public class WeatherDisplay {
	JFrame myFrame = null;

	public static void main(String[] a) {
		(new WeatherDisplay()).test();
	}

	private void test() {
		myFrame = new JFrame("Weather Display");
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setSize(147, 172);
		JEditorPane myPane = new JEditorPane();
		myPane.setContentType("text/html");
		myPane.setText(
				"<!-- weather widget start --><a target=\"_blank\" href=\"https://www.booked.net/weather/montreal-30575\"><img src=\"https://w.bookcdn.com/weather/picture/28_30575_1_1_e67e22_250_d35401_ffffff_ffffff_1_2071c9_ffffff_0_6.png?scode=2&domid=w209&anc_id=98095\" alt=\"booked.net\"/></a><!-- weather widget end -->");

		myFrame.setContentPane(myPane);
		myFrame.setVisible(true);
	}
}
