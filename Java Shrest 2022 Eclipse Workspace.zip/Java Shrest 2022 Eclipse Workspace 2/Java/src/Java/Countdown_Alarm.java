package Java;

import java.awt.Toolkit;
import java.io.IOException;

public class Countdown_Alarm {
	public static void main(String args[]) throws IOException {
		try {

			System.out.println("Countdown started!");
			Thread.sleep(10);
			for (int x = 10; x >= 0; x--) {
				System.out.println(x);

				Thread.sleep(600);
			}
			Thread.sleep(2000);
			Toolkit.getDefaultToolkit().beep();
			System.out.println("END");

		} catch (InterruptedException e) {
		}

	}
}// }
