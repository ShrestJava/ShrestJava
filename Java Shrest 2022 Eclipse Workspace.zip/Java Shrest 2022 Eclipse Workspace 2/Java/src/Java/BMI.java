package Java;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class BMI {
	public static void main(String[] args) {
		JFrame window = new JFrame("BMI");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(1000, 600);
		window.setResizable(false);
		JPanel pan = new JPanel();
		JPanel pan1 = new JPanel();
		pan.setLayout(null);
		pan1.setLayout(null);
		window.setContentPane(pan);
		pan.add(pan1);
		TitledBorder panTitle = new TitledBorder(" Insert info ");
		TitledBorder winTitle = new TitledBorder(" Body Mass Index ");
		panTitle.setTitleJustification(TitledBorder.CENTER);
		winTitle.setTitleJustification(TitledBorder.CENTER);
		pan.setBorder(winTitle);
		pan1.setBackground(Color.LIGHT_GRAY);
		pan1.setBounds(50, 50, 200, 400);
		pan1.setBorder(panTitle);
		JButton addBtn = new JButton("Add");
		addBtn.setBounds(30, 370, 150, 20);
		JButton delete = new JButton("Delete");
		pan.add(delete);
		delete.setBounds(670, 470, 150, 20);
		JTextField name = new JTextField();
		name.setBounds(40, 40, 120, 20);
		JTextField Lname = new JTextField();
		Lname.setBounds(name.getLocation().x, name.getLocation().x + 40, 120, 20);
		pan1.add(addBtn);
		pan1.add(name);
		pan1.add(Lname);

		JLabel txt = new JLabel("Insert :");
		JLabel FName = new JLabel("First Name :");
		JLabel LName = new JLabel("Last Name :");
		JLabel Gender = new JLabel("Gender :");
		JLabel bd = new JLabel("Age :");
		JLabel field = new JLabel("Height : (m)");
		JLabel field2 = new JLabel("Weight :(Kg)");

		JSpinner aut = new JSpinner(new SpinnerNumberModel(0.00, null, null, 0.01));
		pan1.add(aut);
		JSpinner poid = new JSpinner(new SpinnerNumberModel(0, 0, null, 1));
		pan1.add(poid);
		pan1.add(bd);
		pan1.add(field);
		pan1.add(field2);
		pan1.add(Gender);
		JRadioButton male = new JRadioButton("Boy");
		JRadioButton female = new JRadioButton("Girl");
		ButtonGroup gander = new ButtonGroup();
		JSpinner age = new JSpinner(new SpinnerNumberModel(0, 0, null, 1));
		pan1.add(age);
		age.setBounds(40, 240, Lname.getSize().width, Lname.getSize().height + 10);
		field.setBounds(age.getLocation().x, age.getLocation().y + 40, Lname.getSize().width,
				Lname.getSize().height + 10);
		field2.setBounds(age.getLocation().x + 70, age.getLocation().y + 40, (Lname.getSize().width) + 10 / 2,
				Lname.getSize().height + 10);
		aut.setBounds(field.getLocation().x, field.getLocation().y + 30, (Lname.getSize().width) / 2,
				Lname.getSize().height + 10);
		poid.setBounds(field.getLocation().x + 70, field.getLocation().y + 30, (Lname.getSize().width) / 2,
				Lname.getSize().height + 10);
		bd.setBounds(age.getLocation().x, age.getLocation().y - 30, Lname.getSize().width, Lname.getSize().height + 10);
		gander.add(male);
		gander.add(female);
		pan1.add(male);
		pan1.add(female);
		male.setBounds(Lname.getLocation().x, Lname.getLocation().y + 60, Lname.getSize().width,
				Lname.getSize().height + 10);
		female.setBounds(Lname.getLocation().x, Lname.getLocation().y + 85, Lname.getSize().width,
				Lname.getSize().height + 10);
		FName.setBounds(name.getLocation().x, name.getLocation().y - 20, name.getSize().width, name.getSize().height);
		LName.setBounds(Lname.getLocation().x, Lname.getLocation().y - 20, Lname.getSize().width,
				Lname.getSize().height);
		Gender.setBounds(male.getLocation().x, male.getLocation().y - 30, Lname.getSize().width,
				Lname.getSize().height + 10);
		pan1.add(FName);
		pan1.add(LName);
		JLabel INFO = new JLabel("");
		INFO.setBounds(350, 545, 300, 20);
		pan.add(INFO, BorderLayout.PAGE_END);
		JPanel pan2 = new JPanel();
		pan2.setBounds(50, 50, 300, 400);
		pan2.setBounds(pan1.getLocation().x + 300, pan1.getLocation().x, 500, pan1.getSize().height);
		pan2.setBorder(BorderFactory.createLineBorder(Color.black));
		pan.add(pan2);
		String[] columns = { "First Name", "Last Name", "Age", "Gander", "BMI", "Note" };
		DefaultTableModel model = new DefaultTableModel(columns, 0);
		JTable table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setVisible(true);
		pan2.add(scrollPane);
		TableColumn column = null;
		for (int i = 0; i < 6; i++) {
			column = table.getColumnModel().getColumn(i);
			if (i == 2) {
				column.setPreferredWidth(100); // third column is bigger
			} else {
				column.setPreferredWidth(75);
			}
		}
		Object data1[] = {

		};
		model.addRow(data1);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		table.setFillsViewportHeight(true);
		pan2.add(table.getTableHeader(), BorderLayout.NORTH);
		pan2.add(table, BorderLayout.CENTER);
		pan2.setBackground(Color.GRAY);
		addBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				double bmi = Double.parseDouble(poid.getValue().toString())
						/ Math.pow(Double.parseDouble(aut.getValue().toString()), 2);
				String BMI = String.format("%1$,.2f", bmi);
				if (name.getText() != "" && Lname.getText() != "" && (male.isSelected() || female.isSelected())) {
					String gander;
					if (male.isSelected())
						gander = male.getText();
					else
						gander = female.getText();
					String remarque;
					if (bmi > 25.0 && bmi < 30)
						remarque = "Overweight";
					else if (bmi >= 18.50 && bmi <= 24.9)
						remarque = "Healthy";
					else if (bmi >= 30 && bmi <= 35)
						remarque = "Obese Class 1";
					else if (bmi >= 35 && bmi <= 40)
						remarque = "Obese Class 2";
					else if (bmi >= 40)
						remarque = "Obese Class 3";
					else if (bmi >= 15 && bmi <= 16)
						remarque = "Severely Underweight";
					else if (bmi < 15)
						remarque = "Very Severely Underweight";
					else if (bmi >= 16 && bmi <= 18.50)
						remarque = "Underweight";
					else
						remarque = "DEADLY BMI (EXTREMELY SEVERE UNDERWEIGHT OF EXTREMELY SEVERE OBESE!)";
					Object data[] = { name.getText(), Lname.getText(), age.getValue(), gander, BMI, remarque };
					model.addRow(data);
				} else
					JOptionPane.showMessageDialog(null, "You must complete the formula !!");
			}
		});

		delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int count = 0;
				for (int i = 0; i < model.getRowCount(); i++) {
					if (table.isRowSelected(i)) {
						count++;
					}
				}
				if (count == 0) {
					JOptionPane.showMessageDialog(null, "Select to delete");
				} else
					((DefaultTableModel) table.getModel()).removeRow(table.getSelectedRow());
			}

		});
		window.setVisible(true);
	}
}