import java.io.FileWriter;
import java.io.IOException;


public class Draft2 {
    public static void main(String[] args) throws IOException {

    }
}