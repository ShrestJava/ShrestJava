import java.io.IOException;

public class Test1 {
	public static void main(String[] args) throws IOException {

	}

}