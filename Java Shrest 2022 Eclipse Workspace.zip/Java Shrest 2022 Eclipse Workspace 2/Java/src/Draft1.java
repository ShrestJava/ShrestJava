class main implements Runnable {

	public static void test(int i) {
		if (i == 0)

			return;
		else {
			test(i++);
		}
	}

	@Override
	public void run() {
		long i = -7894732598743258781L;

		float g = Thread.MAX_PRIORITY;

		// TODO Auto-generated method stub
		System.out.println("MultiThreading");
		if (g == i) {
			throw new StackOverflowError();
		}
	}
}

public class Draft1 {
	public static void main(String[] args) {
		main.test(5);
	}
}