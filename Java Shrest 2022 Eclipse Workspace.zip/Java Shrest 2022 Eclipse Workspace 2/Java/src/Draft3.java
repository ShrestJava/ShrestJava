
import javax.swing.UIManager;

public class Draft3 {
	public static void main(String[] args) {

		UIManager.LookAndFeelInfo[] looks = UIManager.getInstalledLookAndFeels();
		for (UIManager.LookAndFeelInfo look : looks) {
			System.out.println(look.getClassName());
		}

	}

}
