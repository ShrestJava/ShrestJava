package Tutorial;

public class StringConcatination {
	private static final String Str = "hi";

	public static void main(String[] args) {

// concatination using "+" operator
		String s1 = "Hello ";
		String s2 = "World!";
		String s3 = s1 + s2;
		System.out.println(s3);
		// Concatination using StringBuffer Class
		StringBuffer hi = new StringBuffer();
		hi.append("Hello").append(" ").append("StringBuffer"); // call append method specifying string to be
																// concatenated
		System.out.println(hi);
// concatination using StringBuilder class
		StringBuilder sb = new StringBuilder(); // create string builder instance
		sb.append("Hello").append(" ").append("StringBuilder"); // call append method specifying string to be
																// concatenated
// concatination using the ".concat()" string method\
		String str1 = "Second";
		String str = "First";
		String str2 = str.concat(str1); // using concat method
		System.out.println(str2);
	}
}
