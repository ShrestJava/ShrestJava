package Tutorial;

import java.util.Scanner;

public class UserInput {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number: ");
		int h = sc.nextInt();
		System.out.println("You entered: " + h);
	}
}
