package Tutorial;

//The instanceof keyword checks whether an object is an instance of a specific class or an interface.

//The instanceof keyword compares the instance with type. The return value is either true or false.

public class InstanceofKeyword {
	public static void main(String[] args) {
		InstanceofKeyword myObj = new InstanceofKeyword();
		System.out.println(myObj instanceof InstanceofKeyword); // returns true
	}
}