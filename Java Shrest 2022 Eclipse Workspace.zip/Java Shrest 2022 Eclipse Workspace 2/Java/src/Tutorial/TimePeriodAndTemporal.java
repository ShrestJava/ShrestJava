package Tutorial;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.Temporal;

public class TimePeriodAndTemporal {
	public static void main(String[] args) {
		Period period = Period.of(0, 0, 0);
		Temporal temp = period.addTo(LocalDate.now());
		System.out.println(period);
	}
}

// another Period example
/*
 * import java.time.Period; public class PeriodExample3 { public static void
 * main(String[] args) { Period period1 = Period.ofMonths(4); Period period2 =
 * period1.minus(Period.ofMonths(2)); Period period3 =
 * period2.plus(Period.ofMonths(3)); System.out.println(period3); } }
 */

