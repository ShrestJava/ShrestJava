package Tutorial;

import java.util.Hashtable;
import java.util.Map;

public class HashTable {
	public static void main(String args[]) {
		Hashtable<Integer, String> hm = new Hashtable<Integer, String>();

		hm.put(100, "Shrest The Best");
		hm.put(102, "Srinivas");
		hm.put(101, "Vineela");
		hm.put(103, "Ishanvi");

		for (Map.Entry m : hm.entrySet()) {
			// prints the values descending by key
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}

// the following code adds valus if they are absent in the initial Hashtable
class HashtableExample {
	public static void main(String args[]) {
		Hashtable<Integer, String> map = new Hashtable<Integer, String>();
		map.put(100, "Shrest");
		map.put(102, "Ishanvi");
		map.put(101, "Srini");
		map.put(103, "Vineela");
		System.out.println("Initial Map: " + map);
		// Inserts, as the specified pair is unique
		map.putIfAbsent(104, "OTHER PERSON");
		System.out.println("Updated Map: " + map);
		// Returns the current value, as the specified pair already exist
		map.putIfAbsent(101, "Shrest");
		System.out.println("Updated Map: " + map);
	}
}