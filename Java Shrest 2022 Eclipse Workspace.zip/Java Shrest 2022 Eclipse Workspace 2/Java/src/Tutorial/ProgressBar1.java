package Tutorial;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

import Swing.Shrest;

public class ProgressBar1 extends JFrame {
	JProgressBar jb;
	int i = 0, num = 0;

	ProgressBar1() {
		jb = new JProgressBar(0, 2000);
		jb.setBounds(40, 40, 160, 30);
		jb.setValue(0);
		jb.setStringPainted(true);
		add(jb);
		setSize(250, 150);
		setLayout(null);
	}

	public void iterate() {
		while (i <= 2000) {
			jb.setValue(i);
			i = i + 2;
			try {
				Thread.sleep(1);
				Shrest h = new Shrest();
			} catch (Exception e) {
			}
		}
	}

	public static void main(String[] args) {
		ProgressBar1 m = new ProgressBar1();
		m.setVisible(true);
		m.iterate();
	}
}
