package Tutorial;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDescendingOrder {
	public static void main(String args[]) {
		TreeSet<String> set = new TreeSet<String>();
		set.add("one");
		set.add("two");
		set.add("three");
		System.out.println("Traversing element through Iterator in descending order");
		Iterator i = set.descendingIterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}

	}
}