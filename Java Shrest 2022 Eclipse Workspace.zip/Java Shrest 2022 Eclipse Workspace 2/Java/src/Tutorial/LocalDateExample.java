package Tutorial;

import java.time.LocalDate;

public class LocalDateExample {
	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		LocalDate yesterday = date.minusDays(1);
		LocalDate tomorrow = yesterday.plusDays(2);
		System.out.println("Today date: " + date);
		System.out.println("Yesterday date: " + yesterday);
		System.out.println("Tomorrow date: " + tomorrow);
	}
}
// localDate Example 2
/*
 * public class LocalDateExample2 { public static void main(String[] args) {
 * LocalDate date1 = LocalDate.of(2017, 1, 13);
 * System.out.println(date1.isLeapYear()); LocalDate date2 = LocalDate.of(2016,
 * 9, 23); System.out.println(date2.isLeapYear()); } }
 * 
 */

// Convert LocalDate to string
// Converting LocalDate to String  

/*
 * LocalDate d1 = LocalDate.now(); String d1Str =
 * d1.format(DateTimeFormatter.ISO_DATE);
 * System.out.println("Date1 in string :  " + d1Str);
 */