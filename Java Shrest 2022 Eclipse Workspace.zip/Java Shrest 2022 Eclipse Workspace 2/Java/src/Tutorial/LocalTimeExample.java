package Tutorial;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LocalTimeExample {
	public static void main(String[] args) throws InterruptedException {
		String timeColonPattern = "'Time:' hh:mm:ss a";
		DateTimeFormatter timeColonFormatter = DateTimeFormatter.ofPattern(timeColonPattern);
// the following while loop prints the time in the "hh:mm:ss AM/PM" Format. It prints a new time every second
		while (LocalTime.now().format(timeColonFormatter) != null) {

			System.out.println(LocalTime.now().format(timeColonFormatter));
			Thread.sleep(1000);
		}
	}
}
/*
 * LocalTime time1 = LocalTime.now(); System.out.println(time1); LocalTime
 * time2=time1.minusHours(2); LocalTime time3=time2.minusMinutes(34);
 * System.out.println("The Time now minus 2h34min "time3);
 */