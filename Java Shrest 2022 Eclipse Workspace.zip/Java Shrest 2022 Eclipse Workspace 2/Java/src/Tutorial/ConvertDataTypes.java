package Tutorial;

public class ConvertDataTypes {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// Integer -> string
		int hello = 12;
		String helloString = Integer.toString(hello);
		// long -> string
		long long1 = 8999999999999999999L;
		String long2 = Long.toString(long1);
		// Float -> string
		float num = 15.6f;
		String num2 = Float.toString(num);
		// Double -> string
		double hi = 15;
		String hi2 = Double.toString(hi);
		// String -> int
		String str = "15";
		int str2 = Integer.parseInt(str);
		// Byte -> string
		byte bit = 15;
		String bit2 = Byte.toString(bit);
		// String -> double
		String hey = "15";
		double hey2 = Double.parseDouble(hey);
		// String -> float
		String wave = "15";
		float wave2 = Float.parseFloat(hey);
		// String -> float
		String byte1 = "15";
		byte byte2 = Byte.parseByte(byte1);
		// String -> long
		String heyguys = "152456789L";
		long heyguys2 = Long.parseLong(heyguys);

	}
}
