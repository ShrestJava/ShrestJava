package Tutorial;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ArrayList_And_LinkedList {
	public static void main(String args[]) {

		List<String> al = new ArrayList<String>();// creating arraylist
		al.add("Shrest");// adding object in arraylist
		al.add("Srinivas");
		al.add("Vineela");
		al.add("Ishanvi");

		List<String> al2 = new LinkedList<String>();// creating linkedlist
		al2.add("Ammamma");// adding object in linkedlist
		al2.add("Thathaya");
		al2.add("Bharath Mama");
		al2.add("Sravanthi Atha");
		al2.add("Shreenika");
		al2.add("Thathama");

		System.out.println("arraylist: " + al);
		System.out.println("linkedlist: " + al2);
		System.out.println("Arraylist + linkedlist: " + al.toString() + al2.toString());
	}
}
