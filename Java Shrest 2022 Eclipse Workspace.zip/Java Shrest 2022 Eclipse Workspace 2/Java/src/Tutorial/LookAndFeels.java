package Tutorial;

import com.formdev.flatlaf.demo.FlatLafDemo;

public class LookAndFeels {
public static void main(String[] args) {

FlatLafDemo d = new FlatLafDemo();
d.main(args);
}

}
