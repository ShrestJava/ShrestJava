package Tutorial;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

enum days {
	SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}

public class EnumSetExample {
	public static int i;

	public static void main(String[] args) {
		for (i = 0; i < days.values().length; i++) {
			Set<days> set = EnumSet.of(days.values()[i]);
			// Traversing elements
			Iterator<days> iter = set.iterator();
			while (iter.hasNext())
				System.out.println(iter.next());
		}

	}
}