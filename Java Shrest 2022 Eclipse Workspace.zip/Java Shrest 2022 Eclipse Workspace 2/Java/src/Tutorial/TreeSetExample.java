package Tutorial;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample {
	public static void main(String args[]) {
		// Creating and adding elements
		TreeSet<String> al = new TreeSet<String>();
		al.add("one");
		al.add("two");
		al.add("three");
		al.add("four");
		// Traversing elements. it will show: four, one, three, two like a tree diagram
		// TreeSet ignores duplicates in the element entry
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}