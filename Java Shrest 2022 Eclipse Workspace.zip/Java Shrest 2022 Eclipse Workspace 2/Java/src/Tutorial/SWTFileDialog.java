package Tutorial;

import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;

public class SWTFileDialog {

	public static void main(String[] args) {
		final JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new GridLayout(0, 1));
		frame.add(new JButton(new AbstractAction("Load") {

			@Override
			public void actionPerformed(ActionEvent e) {
				FileDialog fd = new FileDialog(frame, "Test", FileDialog.LOAD);
				fd.setVisible(true);
				System.out.println(fd.getFile());
			}
		}));
		frame.add(new JButton(new AbstractAction("Save") {

			@Override
			public void actionPerformed(ActionEvent e) {
				FileDialog fd = new FileDialog(frame, "Test", FileDialog.SAVE);
				fd.setVisible(true);
				System.out.println(fd.getFile());
			}
		}));
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}