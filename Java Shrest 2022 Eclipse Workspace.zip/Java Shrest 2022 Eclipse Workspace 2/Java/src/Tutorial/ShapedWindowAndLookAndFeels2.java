package Tutorial;

import java.awt.GridBagLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UnsupportedLookAndFeelException;

import com.formdev.flatlaf.demo.FlatLafDemo;
import com.formdev.flatlaf.intellijthemes.FlatAllIJThemes;

public class ShapedWindowAndLookAndFeels2 {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException, UnsupportedLookAndFeelException {

		
		// you could use classes from the flatlaf-intellij-themes-2.0.jar library and use their setup() method Example: FlatCyanLightIJTheme.setup();	


		FlatLafDemo d = new FlatLafDemo();
		d.main(args);

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels2.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels2.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels2.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels2.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		}
		// JFrame.setDefaultLookAndFeelDecorated(true);

		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");

		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		// UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");

		// Create the GUI on the event-dispatching thread
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				createWindow();
			}
		});
	}

	private static void createWindow() {
		JFrame frame = new JFrame("Rounded Shaped Window");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		createUI(frame);
		frame.setVisible(true);
	}

	private static void createUI(final JFrame frame) {
		frame.setLayout(new GridBagLayout());
		frame.setSize(200, 200);
		frame.setLocationRelativeTo(null);
		frame.add(new JButton("Hello World"));

		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				 frame.setShape(new RoundRectangle2D.Double(0, 0, frame.getWidth(),
			 frame.getHeight(), 20, 20));
			}
		});
	}
}