package Tutorial;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegEx_OccurenceFinder {
	public static void main(String[] args) {

		/*
		 * System.out.println(Pattern.matches(".s", "as")); the code returns true
		 * because it checks if the character "s" in the second character of "as" The .
		 * (dot) represents a single character.
		 */
		Pattern pattern = Pattern.compile("shrest", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher("shrest the best!");
		boolean matchFound = matcher.find();
		if (matchFound) { /// replace
			System.out.println(matcher.replaceFirst(""));
			System.out.println("Match found");
		} else {
			System.out.println("Match not found");
		}
	}
}