package Tutorial;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapExample {
	public static void main(String args[]) {
		TreeMap<Integer, String> map = new TreeMap<Integer, String>();
		map.put(100, "Shrest");
		map.put(102, "Ishanvi");
		map.put(101, "Vineela");
		map.put(103, "Srinivas");
		System.out.println("Before invoking remove() method");
		for (@SuppressWarnings("rawtypes")
		Map.Entry m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
		map.remove(102);
		System.out.println("After invoking remove() method");
		for (@SuppressWarnings("rawtypes")
		Map.Entry m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}