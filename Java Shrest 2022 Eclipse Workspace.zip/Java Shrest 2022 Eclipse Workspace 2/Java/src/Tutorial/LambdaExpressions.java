package Tutorial;
// without lambda 

/*
 interface Drawable{  

    public void draw();  
}  
public class LambdaExpressions {  
    public static void main(String[] args) {  
        int width=10;  
  
        //without lambda, Drawable implementation using anonymous class  
        Drawable d=new Drawable(){  
            public void draw(){System.out.println("Drawing "+width);}  
        };  
        d.draw();  
    }  
}  
*/
// with lambda
/*
interface Drawable {
	public void draw(int width);
}

public class LambdaExpressions {
	public static void main(String[] args) {


		// with lambda
		Drawable d2 = (x) -> {
			System.out.println("Drawing " + x);
		};
		int width = 10;
		d2.draw(width);
	}
}
*/
// NOTE: Final variable can be accessed inside a lambda expression
// another lambda expression

interface Addable {

	int add(int a, int b);
}

public class LambdaExpressions {
	public static void main(String[] args) {

		// Lambda expression without return keyword.
		Addable ad1 = (a, b) -> (a + b);
		System.out.println(ad1.add(10, 20));

		// Lambda expression with return keyword.
		Addable ad2 = (int a, int b) -> {
			return (a + b);
		};
		System.out.println(ad2.add(100, 200));

	}
}
