package Tutorial;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;

public class DictionaryDemo {
	public static void main(String[] args) {
		Dictionary<Integer, String> dic = new Hashtable<Integer, String>();
		dic.put(1, "CSS");
		dic.put(2, "Java");
		dic.put(3, "HTML");
		dic.put(4, "C++");
		dic.put(5, "Python");
		dic.put(6, "Perl");
		dic.put(7, "JavaScript");
		dic.put(8, "PHP");
		dic.put(9, "C#");
		dic.put(10, "XML");
		dic.put(11, "SQL");

		System.out.println("Size of the dictionary: " + dic.size());
		System.out.println("Value of the key 3: " + dic.get(3));

		// Iterate over elements in dictionary
		System.out.println("Iterating using enumeration:");
		Enumeration<String> e = dic.elements();
		while (e.hasMoreElements())
			System.out.print(e.nextElement() + " ");

		System.out.println("\nDisplay the keys:");
		Enumeration<Integer> ekey = dic.keys();
		while (ekey.hasMoreElements())
			System.out.print(ekey.nextElement() + " ");

		dic.remove(4);
		System.out.println("\nValues after removing element at key 4:" + dic);
		// Update value at key 3
		dic.put(3, "Lua");
		System.out.println("Value at index 3: " + dic.get(3));

		System.out.println("Is dictionary empty: " + dic.isEmpty());
	}

}