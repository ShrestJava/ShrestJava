package Tutorial;

// the following method overrides the run method from class Thread
// the following code demonstrates how to create a thread by saying extends Thread
class ThreadsEx1 extends Thread {

	public void run() {
		System.out.println("This code is running in a thread");
	}
}

// the following method overrides the run method from class Thread
// the following code demonstrates how to create a thread by saying implements Runnable
class ThreadsEx2 implements Runnable {

	public void run() {
		System.out.println("This code is running in a thread");
	}
}

// the following code shows how to run a thread using extends
class RunExtends extends Thread {
	public static void main(String[] args) {
		RunExtends thread = new RunExtends();
		thread.start();
		System.out.println("This code is outside of the thread");
	}

	public void run() {
		System.out.println("This code is running in a thread");
	}
}

// the following code shows you how to run a thread using implements
class RunImplements implements Runnable {
	public static void main(String[] args) {
		RunImplements obj = new RunImplements();
		Thread thread = new Thread(obj);
		thread.start();
		System.out.println("This code is outside of the thread");
	}

	public void run() {
		System.out.println("This code is running in a thread");
	}
}
/*
 * Differences between "extending" and "implementing" Threads
 * 
 * The major difference is that when a class extends the Thread class, you
 * cannot extend any other class, but by implementing the Runnable interface, it
 * is possible to extend from another class as well, like: class MyClass extends
 * OtherClass implements Runnable.
 */