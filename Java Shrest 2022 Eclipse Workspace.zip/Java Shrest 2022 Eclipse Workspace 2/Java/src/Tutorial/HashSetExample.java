package Tutorial;

//  Notice, the elements iterate in an unordered collection.
import java.util.Iterator;

public class HashSetExample {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String args[]) {
		// Creating HashSet and adding elements
		java.util.HashSet<String> set = new java.util.HashSet();
		set.add("One");
		set.add("Two");
		set.add("Three");
		set.add("Four");
		set.add("Five");
		Iterator<String> i = set.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
/*
 * public class HashSetExample{ // HashSet ignores duplicates, it doesn't print
 * duplicates public static void main(String args[]){ //Creating HashSet and
 * adding elements HashSet<String> set=new HashSet<String>(); set.add("Shrest");
 * set.add("Srinivas"); set.add("Ishanvi"); set.add("Vineela");
 * set.add("Shrest"); //Traversing elements Iterator<String> itr=set.iterator();
 * while(itr.hasNext()){ System.out.println(itr.next()); } } }
 */

// the following code demonstrates different ways to delete elements in HashSet
/*
 * public class HashSetExampleDelete{
 * 
 * public static void main(String args[]){ HashSet<String> set=new
 * HashSet<String>(); set.add("Shrest"); set.add("Ishanvi");
 * set.add("Srinivas"); set.add("Vineela");
 * System.out.println("An initial list of elements: "+set); //Removing specific
 * element from HashSet set.remove("Ravi");
 * System.out.println("After invoking remove(object) method: "+set);
 * HashSet<String> set1=new HashSet<String>(); set1.add("Shrest");
 * set1.add("Srinivas"); set.addAll(set1);
 * System.out.println("Updated List: "+set); //Removing all the new elements
 * from HashSet set.removeAll(set1);
 * System.out.println("After invoking removeAll() method: "+set); //Removing
 * elements on the basis of specified condition
 * set.removeIf(str->str.contains("Ishanvi"));
 * System.out.println("After invoking removeIf() method: "+set); //Removing all
 * the elements available in the set set.clear();
 * System.out.println("After invoking clear() method: "+set); } }
 */