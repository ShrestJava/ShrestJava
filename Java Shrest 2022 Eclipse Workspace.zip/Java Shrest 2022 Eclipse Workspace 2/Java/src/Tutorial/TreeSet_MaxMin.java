package Tutorial;

import java.util.TreeSet;

public class TreeSet_MaxMin {
	public static void main(String args[]) {
		TreeSet<Double> set = new TreeSet<Double>();
		set.add(6237.93248);
		set.add(2347823.42);
		set.add(23423.84398);
		set.add(3242.48);
		System.out.println("Lowest Value: " + set.pollFirst());
		System.out.println("Highest Value: " + set.pollLast());
	}
}