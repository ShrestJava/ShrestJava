package Tutorial;

import java.awt.GridBagLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.multi.MultiLookAndFeel;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.demo.FlatLafDemo;
import com.formdev.flatlaf.intellijthemes.FlatArcIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatCarbonIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatCobalt2IJTheme;
import com.formdev.flatlaf.intellijthemes.FlatGradiantoDarkFuchsiaIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatHighContrastIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatNordIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatOneDarkIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatSpacegrayIJTheme;
import com.formdev.flatlaf.intellijthemes.FlatVuesionIJTheme;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialOceanicContrastIJTheme;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMoonlightContrastIJTheme;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMoonlightIJTheme;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatNightOwlContrastIJTheme;
import com.jtattoo.plaf.acryl.AcrylLookAndFeel;

public class ShapedWindowAndLookAndFeels {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException, UnsupportedLookAndFeelException {

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("".equals(info.getName())) {
					
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

		} catch (ClassNotFoundException ex) {
			
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(ShapedWindowAndLookAndFeels.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		}
		// JFrame.setDefaultLookAndFeelDecorated(true);

		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		// UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		// UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.noire.NoireLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");
		// UIManager.setLookAndFeel(new FlatDarculaLaf());
		// UIManager.setLookAndFeel(new FlatDarkLaf());
		// UIManager.setLookAndFeel(new FlatLightLaf());
		// UIManager.setLookAndFeel(new FlatIntelliJLaf());
		// UIManager.setLookAndFeel(new FlatCobalt2IJTheme());
		// UIManager.setLookAndFeel(new FlatArcIJTheme());
		// UIManager.setLookAndFeel(new FlatHighContrastIJTheme());
		// UIManager.setLookAndFeel(new FlatCarbonIJTheme());
		// UIManager.setLookAndFeel(new FlatNordIJTheme());
		// UIManager.setLookAndFeel(new FlatGradiantoDarkFuchsiaIJTheme());
		// UIManager.setLookAndFeel(new FlatOneDarkIJTheme());
		// UIManager.setLookAndFeel(new FlatVuesionIJTheme());
		// UIManager.setLookAndFeel(new FlatSpacegrayIJTheme());
		// UIManager.setLookAndFeel(new FlatMoonlightContrastIJTheme());
		// UIManager.setLookAndFeel(new FlatMoonlightIJTheme());
		// UIManager.setLookAndFeel(new FlatMaterialOceanicContrastIJTheme());		
		// UIManager.setLookAndFeel(new FlatNightOwlContrastIJTheme());		
		// UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.bernstein.BernsteinLookAndFeel");		
		// UIManager.setLookAndFeel("com.jtattoo.plaf.aero.AeroLookAndFeel");
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.fast.FastLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.graphite.GraphiteLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.luna.LunaLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		// UIManager.setLookAndFeel("com.jtattoo.plaf.mint.MintLookAndFeel");
		
		
		
		// Create the GUI on the event-dispatching thread
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				createWindow();
			}
		});
	}

	private static void createWindow() {
		JFrame frame = new JFrame("Look And Feel");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		createUI(frame);
		frame.setVisible(true);
	}

	private static void createUI(final JFrame frame) {
		frame.setLayout(new GridBagLayout());
		frame.setSize(200, 200);
		frame.setLocationRelativeTo(null);
		frame.add(new JButton("Hello World"));

		frame.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
		//	 frame.setShape(new RoundRectangle2D.Double(0, 0, frame.getWidth(),
			//	 frame.getHeight(), 20, 20));
			}
		});
	}
}