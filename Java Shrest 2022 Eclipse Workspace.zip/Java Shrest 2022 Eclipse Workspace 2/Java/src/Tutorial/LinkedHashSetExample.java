package Tutorial;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetExample {
	public static void main(String args[]) {
		// Creating HashSet and adding elements
		LinkedHashSet<String> set = new LinkedHashSet();
		set.add("One");
		set.add("Two");
		set.add("Three");
		set.add("Four");
		set.add("Five");
		Iterator<String> i = set.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
// the following code demonstrates how LinkedHashSet ignores duplictes
/*
 * import java.util.*;
 * 
 * class LinkedHashSet2{ public static void main(String args[]){
 * LinkedHashSet<String> al=new LinkedHashSet<String>(); al.add("Shrest");
 * al.add("Srinivas"); al.add("Shrest"); al.add("Ishanvi"); Iterator<String>
 * itr=al.iterator(); while(itr.hasNext()){ System.out.println(itr.next()); } }
 * }
 */

// LinkedHashSet example: book
/*
 * import java.util.*; class Book { int id; String name,author,publisher; int
 * quantity; public Book(int id, String name, String author, String publisher,
 * int quantity) { this.id = id; this.name = name; this.author = author;
 * this.publisher = publisher; this.quantity = quantity; } }
 * 
 * 
 * public class LinkedHashSetExample { public static void main(String[] args) {
 * LinkedHashSet<Book> hs=new LinkedHashSet<Book>(); //Creating Books Book
 * b1=new Book(101,"Let us C","Yashwant Kanetkar","BPB",8); Book b2=new
 * Book(102,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);
 * Book b3=new Book(103,"Operating System","Galvin","Wiley",6); //Adding Books
 * to hash table hs.add(b1); hs.add(b2); hs.add(b3); //Traversing hash table
 * for(Book b:hs){
 * System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.
 * quantity); } } }
 */