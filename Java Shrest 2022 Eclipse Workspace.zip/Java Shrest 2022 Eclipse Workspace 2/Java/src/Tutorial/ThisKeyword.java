package Tutorial;
/*
public class ThisKeyword {
	
	 // NOTE: Using this with a Field. The most common reason for using the this
	 // keyword is because a field is shadowed by a method or constructor parameter.
	 
	ThisKeyword() {
		this("Shrest");
		System.out.println("Inside Constructor without parameter");
	}

	ThisKeyword(String str) {
		System.out.println("Inside Constructor with String parameter as " + str);
	}

	public static void main(String[] args) {
		ThisKeyword obj = new ThisKeyword();
	}
}
*/

// NOTE this.methodOne();// is same as calling methodOne()

public class ThisKeyword {
	int variable = 5;

	public static void main(String args[]) {
		ThisKeyword obj = new ThisKeyword();

		obj.method(20);
		obj.method();
	}

	void method(int variable) {
		variable = 10;
		System.out.println("Value of Instance variable :" + this.variable);
		System.out.println("Value of Local variable :" + variable);
	}

	void method() {
		int variable = 40;
		System.out.println("Value of Instance variable :" + this.variable);
		System.out.println("Value of Local variable :" + variable);
	}
}
