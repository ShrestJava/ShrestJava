package Tutorial;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class Tree_diagram {
	JFrame f;

	Tree_diagram() {
		f = new JFrame();
		DefaultMutableTreeNode Folder = new DefaultMutableTreeNode("Folder");
		DefaultMutableTreeNode style = new DefaultMutableTreeNode("Family");
		DefaultMutableTreeNode color = new DefaultMutableTreeNode("Core");
		DefaultMutableTreeNode font = new DefaultMutableTreeNode("Extended");
		style.add(color);
		style.add(font);
		DefaultMutableTreeNode red = new DefaultMutableTreeNode("Shrest");
		DefaultMutableTreeNode blue = new DefaultMutableTreeNode("Ishanvi");
		DefaultMutableTreeNode black = new DefaultMutableTreeNode("Srinivas");
		DefaultMutableTreeNode yellow = new DefaultMutableTreeNode("Vineela");
		DefaultMutableTreeNode white = new DefaultMutableTreeNode("Bharath");
		DefaultMutableTreeNode white1 = new DefaultMutableTreeNode("Sravanthi");
		DefaultMutableTreeNode white2 = new DefaultMutableTreeNode("Shreenika");
		DefaultMutableTreeNode white3 = new DefaultMutableTreeNode("Anuradha");
		DefaultMutableTreeNode white4 = new DefaultMutableTreeNode("Surender");

		DefaultMutableTreeNode white5 = new DefaultMutableTreeNode("Tukaram");
		DefaultMutableTreeNode white6 = new DefaultMutableTreeNode("Padmaja");

		DefaultMutableTreeNode white7 = new DefaultMutableTreeNode("Nandini");
		DefaultMutableTreeNode white8 = new DefaultMutableTreeNode("Buchama");
		DefaultMutableTreeNode white9 = new DefaultMutableTreeNode("Narsaya");
		DefaultMutableTreeNode white10 = new DefaultMutableTreeNode("Shanthama");

		color.add(red);
		color.add(blue);
		color.add(black);
		color.add(yellow);
		font.add(white);
		font.add(white1);
		font.add(white2);
		font.add(white3);
		font.add(white4);
		font.add(white5);
		font.add(white6);
		font.add(white7);
		font.add(white8);
		font.add(white9);
		font.add(white10);
		Folder.add(style);
		JTree jt = new JTree(Folder);
		f.add(jt);
		f.setSize(200, 500);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new Tree_diagram();
	}
}
