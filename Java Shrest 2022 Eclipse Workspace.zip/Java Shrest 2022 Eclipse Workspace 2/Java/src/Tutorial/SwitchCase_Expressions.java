package Tutorial;

import java.util.Scanner;

public class SwitchCase_Expressions {

	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter your name: ");
		String str = in.nextLine();
		switch (str) {
		case "Shrest":
			System.out.println("Hello " + str);
			break;
		case "Ishanvi":
			System.out.println("Hello " + str);
			break;
		case "Vineela":
			System.out.println("Hello " + str);
			break;
		case "Srinivas":
			System.out.println("Hello " + str);
			break;
		default:
			System.out.println("Who Are You?!");
		}
	}
}