package Tutorial;

import java.util.Arrays;

public class JavaArrays {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		int array[] = new int[3]; // "array" has 3 elements
		array[1] = 2;
		array[2] = 3;
		array[0] = 1;

		String[] cars = { "Volvo", "Tesla", "BMW", "Mazda" };
		int[] arrayCopy = Arrays.copyOf(array, array.length); // copy array
		int[] arrayCopy1 = Arrays.copyOfRange(array, 1, 2); // array copy of range
		String s = Arrays.toString(arrayCopy); // this decodes the array into readable form THIS STEP IS IMPORTANT!!!
		String s1 = Arrays.toString(arrayCopy1); // this decodes the array into readable form THIS STEP IS IMPORTANT!!!
		Arrays.sort(cars); // sorts values numerically in order
		String hi = Arrays.toString(cars);
		System.out.println(hi);
		Arrays.fill(array, 10);
		int[] myArray = { 10, 20, 30, 40 };
		String FirstValue = cars[0];
		String SecondValue = cars[1];
		String ThirdValue = cars[2];
		String FourthValue = cars[3];
		System.out.println(FirstValue + "\n" + SecondValue + "\n" + ThirdValue + "\n" + FourthValue + "\n");
		System.out.println("Third Value: " + myArray[2]);
		cars[0] = "Ford"; // Changes first value to "Ford"
		System.out.println("Changed First Value: " + cars[0]);
		int Length = cars.length; // Length of array "cars"
		System.out.println("Length of cars: " + Length);
		// Print List of Arrays
		System.out.println("All Items in array \"cars\": ");
		for (int i = 0; i < cars.length; i++) {
			System.out.println(cars[i]);
		}
		System.out.println("\n");
		// Another way to Print List of Arrays
		for (String i : cars) {
			System.out.println(i);
		}
		// Multidimensional Array
		int[][] myNumbers = { { 1, 2, 3, 4 }, { 5, 6, 7 } };
		int x = myNumbers[1][2];
		System.out.println("3rd Value of second Array in multidimensional array \" myNumbers \"" + x); // Outputs 7
		// Print all values of multidimensional array
		System.out.println("Values of multidimensional array");
		for (int i = 0; i < myNumbers.length; ++i) {
			for (int j = 0; j < myNumbers[i].length; ++j) {
				System.out.println(myNumbers[i][j]);
			}
		}

	}
}
