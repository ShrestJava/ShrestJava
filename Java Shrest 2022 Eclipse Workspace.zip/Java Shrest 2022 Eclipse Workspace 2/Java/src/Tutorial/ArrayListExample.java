package Tutorial;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample {
	public static void main(String[] args) {
		// Java ArrayList default constructor
		List<String> vowels = new ArrayList<String>();

		// Java ArrayList constructor with initial capacity
		List<String> dictionaryWordsList = new ArrayList<String>(50000);

		vowels.add("A");
		vowels.add("B");
		vowels.add("C");
		vowels.add("D");
		vowels.add("E");

		// Creating my list from different collection source
		List<String> myList = new ArrayList<String>(vowels);

	}
}
