package Tutorial;

//Program to illustrate super keyword
//refers super-class instance

class Parent {
	// instance variable
	int a = 10;

	// static variable
	static int b = 20;
}

public class SuperKeyword extends Parent {
	void Void() {
		// referring parent class(i.e, class Parent)
		// instance variable(i.e, a)
		System.out.println(super.a);

		// referring parent class(i.e, class Parent)
		// static variable(i.e, b)
		// the super is not needed because b is static
		System.out.println(super.b);

	}

	public static void main(String[] args) {

		// remember one cannot use 'super' in static context.

		new SuperKeyword().Void();
		// NOTE: use super(); to call the parent class
	}
}