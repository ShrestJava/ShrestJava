package Tutorial;

class OuterClass {
	int x = 10;

	class InnerClass {
		int y = 5;
	}
}

public class InnerClasses {
	public static void main(String[] args) {
		OuterClass myOuter = new OuterClass(); // object creation outer class

		OuterClass.InnerClass myInner = myOuter.new InnerClass(); // inner class creation of object

		System.out.println(myInner.y + myOuter.x);
	}
}
