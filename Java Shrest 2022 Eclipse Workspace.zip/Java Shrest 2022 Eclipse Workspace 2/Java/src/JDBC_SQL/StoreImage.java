package JDBC_SQL;

import java.sql.*;  
import java.io.*;  
public class StoreImage {  
public static void main(String[] args) {  
try{  
Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql_database", "root", "root");  

PreparedStatement ps=con.prepareStatement("insert into pictures values(?,?)");  
ps.setString(1,"Ishanvi");  
  
FileInputStream fin=new FileInputStream("C:\\Users\\shres\\Documents\\Shrest\\Pictures\\2018-08\\DSC08254.JPG");  
ps.setBinaryStream(2,fin,fin.available());  
int i=ps.executeUpdate();  
System.out.println(i+" record(s) affected");  
          
con.close();  
}catch (Exception e) {e.printStackTrace();}  
}  
}  