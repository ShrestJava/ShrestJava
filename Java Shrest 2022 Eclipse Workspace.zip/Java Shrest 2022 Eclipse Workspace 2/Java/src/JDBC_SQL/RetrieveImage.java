package JDBC_SQL;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class RetrieveImage extends JFrame 
{
	
  public RetrieveImage(String name) 
  {
    super("Display an image from a MySQL DB");
    setSize(600, 400);
    //get the connection
    Connection con = getConnection();
    try { 
      //creation and execution of the request
      PreparedStatement statement = con.prepareStatement("SELECT image FROM pictures WHERE user = '"+name+"'");
      ResultSet res = statement.executeQuery();

      //get image as byte
      byte[] image = null;
      while (res.next()) {
        image = res.getBytes("image");
      }
      //create the image 
      Image img = Toolkit.getDefaultToolkit().createImage(image);
      ImageIcon icone = new ImageIcon(img);
      JLabel l = new JLabel();
      l.setIcon(icone);
      add(l);

    } catch (SQLException e) {
      e.printStackTrace();
    }
    setVisible(true);
  }

  public Connection getConnection() {
    String url = "jdbc:mysql://localhost:3306/mysql_database";
    //User
    String user = "root";
    //Password
    String password = "root";
    //initiate the connection
    Connection con = null;
    
    try {
      //create the database connection string
      con = DriverManager.getConnection(url, user, password);

    } catch (Exception e) {
      System.out.println("Error "+ e);
    }
    return con;
  }

  public static void main(String[] args) {
    new RetrieveImage("Shrest");
  }
}