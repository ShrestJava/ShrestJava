package JDBC_SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Test {
	public static String pwd = "hhi";

	public static void createConnection() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql_database", "root", "root");
			Statement s = con.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM users");
			System.out.println("Full Name" + "       " + "      Username" + "       " + "Password" + "       "
					+ "Height" + "       " + "Weight" + "       ");
			System.out.println(
					"_________________________________________________________________________________________________");
			while (r.next()) {
				String n = r.getString("Full Name");
				String n1 = r.getString("Username");
				String n2 = r.getString("Password");
				String n3 = r.getString("Height");
				String n4 = r.getString("Weight");

				System.out.println(
						n + "       " + n1 + "       " + "********" + "       " + n3 + "       " + n4 + "       ");
			}

		} catch (ClassNotFoundException e) {
			Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, e);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Test t = new Test();
		createConnection();
	}
}
