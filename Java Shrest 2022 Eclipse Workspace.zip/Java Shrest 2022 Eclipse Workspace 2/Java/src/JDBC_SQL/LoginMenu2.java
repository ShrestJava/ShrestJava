package JDBC_SQL;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UnsupportedLookAndFeelException;

public class LoginMenu2 extends JFrame implements ActionListener {
	private static JLabel Success;
	private static JButton b;
	private static JButton b2;
	private static JPasswordField pwdfield;
	private static JLabel passlbl;
	private static JTextField usertext;
	private static JLabel usrlabel;
	
	private static String sum;
	private static JPanel panel;
	private static JFrame frame;

	public static void main(String[] args) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		sum = JOptionPane.showInputDialog("Enter Your Full Name:");

		JOptionPane.showMessageDialog(null, "Please Click \"Ok\" " + sum, "", JFrame.EXIT_ON_CLOSE);
		panel = new JPanel();
		frame = new JFrame("Please login to your account");
		frame.setSize(450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.add(panel);
		panel.setLayout(null);
		usrlabel = new JLabel("Username");
		usrlabel.setBounds(10, 20, 80, 25);
		panel.add(usrlabel);

		usertext = new JTextField(20);
		usertext.setBounds(100, 20, 165, 25);
		panel.add(usertext);

		passlbl = new JLabel("Password");
		passlbl.setBounds(10, 50, 80, 25);
		panel.add(passlbl);

		pwdfield = new JPasswordField(20);
		pwdfield.setBounds(100, 50, 165, 25);
		pwdfield.setEchoChar('�');
		panel.add(pwdfield);
		b = new JButton("Login");
		b.setBounds(10, 80, 100, 25);
		b.addActionListener(new LoginMenu2());
		panel.add(b);
		b2 = new JButton("Register");
		b2.setBounds(10, 130, 100, 25);
		b2.addActionListener(new LoginMenu2());
		panel.add(b2);

		Success = new JLabel("");
		Success.setBounds(10, 150, 600, 25);
		panel.add(Success);

		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b) {
			String userName = usertext.getText();
			String password = pwdfield.getText();
			try {
				Connection connection = (Connection) DriverManager
						.getConnection("jdbc:mysql://localhost:3306/mysql_database", "root", "root");

				PreparedStatement st = connection
						.prepareStatement("Select Username, Password from users where Username=? and Password=?");

				st.setString(1, userName);
				st.setString(2, password);
				ResultSet rs = st.executeQuery();
				if (rs.next()) {
					try {
						for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
							if ("Metal".equals(info.getName())) {
								javax.swing.UIManager.setLookAndFeel(info.getClassName());
								break;
							}
						}
					} catch (ClassNotFoundException ex) {
						java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
								ex);
					} catch (InstantiationException ex) {
						java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
								ex);
					} catch (IllegalAccessException ex) {
						java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
								ex);
					} catch (javax.swing.UnsupportedLookAndFeelException ex) {
						java.util.logging.Logger.getLogger(LoginMenu2.class.getName()).log(java.util.logging.Level.SEVERE, null,
								ex);
					}
					frame.dispose();
					JOptionPane.showMessageDialog(b, "You have successfully logged in");
					
				Shrest_Swing sw = new Shrest_Swing();
					sw.name = sum;
					sw.main(null);

					UserHome ah = new UserHome(userName);
					ah.setTitle("Welcome");
					ah.setVisible(true);

				} else {
					JOptionPane.showMessageDialog(b, "Wrong Username & Password. Please try again or Sign Up");
				}
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			} catch (UnsupportedLookAndFeelException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (e.getSource() == b2) {
			new RegistrationForm();

		}
	}
}
