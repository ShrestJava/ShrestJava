package JDBC_SQL;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Java.Shrest_Swing;

public class LoginMenu extends JFrame implements ActionListener {
	private static JLabel Success;
	private static JButton b;
	private static JButton b2;
	private static JPasswordField pwdfield;
	private static JLabel passlbl;
	private static JTextField usertext;
	private static JLabel usrlabel;
	private static String sum;
	private static JPanel panel;
	private static JFrame frame;

	public static void main(String[] args) {
		sum = JOptionPane.showInputDialog("Enter Your Full Name:");

		JOptionPane.showMessageDialog(null, "Please Click \"Ok\" " + sum, "", JFrame.EXIT_ON_CLOSE);
		panel = new JPanel();
		frame = new JFrame("Please login to your account");
		frame.setSize(450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.add(panel);
		panel.setLayout(null);
		usrlabel = new JLabel("Username");
		usrlabel.setBounds(10, 20, 80, 25);
		panel.add(usrlabel);

		usertext = new JTextField(20);
		usertext.setBounds(100, 20, 165, 25);
		panel.add(usertext);

		passlbl = new JLabel("Password");
		passlbl.setBounds(10, 50, 80, 25);
		panel.add(passlbl);

		pwdfield = new JPasswordField(20);
		pwdfield.setBounds(100, 50, 165, 25);
		panel.add(pwdfield);
		b = new JButton("Login");
		b.setBounds(10, 80, 80, 25);
		b.addActionListener(new LoginMenu());
		panel.add(b);

		Success = new JLabel("");
		Success.setBounds(10, 110, 600, 25);
		panel.add(Success);

		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b) {
			String userName = usertext.getText();
			String password = pwdfield.getText();
			try {
				Connection connection = (Connection) DriverManager
						.getConnection("jdbc:mysql://localhost:3306/mysql_database", "root", "root");

				PreparedStatement st = connection
						.prepareStatement("Select Username, Password from users where Username=? and Password=?");

				st.setString(1, userName);
				st.setString(2, password);
				ResultSet rs = st.executeQuery();
				if (rs.next()) {

					Shrest_Swing sw = new Shrest_Swing();
					sw.name = sum;
					sw.main(null);
					this.dispose();
					UserHome ah = new UserHome(userName);
					ah.setTitle("Welcome");
					ah.setVisible(true);

					JOptionPane.showMessageDialog(b, "You have successfully logged in");
				} else {
					JOptionPane.showMessageDialog(b, "Wrong Username & Password. Please try again or Sign Up");

				}
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}

	}
}
