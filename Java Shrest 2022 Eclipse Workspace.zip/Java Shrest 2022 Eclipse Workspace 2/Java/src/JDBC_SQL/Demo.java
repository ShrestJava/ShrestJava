package JDBC_SQL;

public class Demo {

}
