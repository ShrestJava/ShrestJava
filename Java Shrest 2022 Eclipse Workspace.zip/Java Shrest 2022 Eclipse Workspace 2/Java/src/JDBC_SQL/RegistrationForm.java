package JDBC_SQL;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class RegistrationForm implements ActionListener {
	JFrame frame;
	String[] gender = { "Male", "Female", "Other" };
	JLabel nameLabel = new JLabel("Full Name: ");
	JLabel genderLabel = new JLabel("Gender: ");
	JLabel fatherNameLabel = new JLabel("Username: ");
	JLabel passwordLabel = new JLabel("Password: ");
	JLabel confirmPasswordLabel = new JLabel("CONFIRM PASSWORD: ");
	JLabel cityLabel = new JLabel("Height: ");
	JLabel emailLabel = new JLabel("Weight: ");
	JTextField nameTextField = new JTextField();
	JComboBox genderComboBox = new JComboBox(gender);
	JTextField userTextField = new JTextField();
	JPasswordField passwordField = new JPasswordField();
	JPasswordField confirmPasswordField = new JPasswordField();
	JTextField heightTextField = new JTextField();
	JTextField weightTextField = new JTextField();
	JButton registerButton = new JButton("Register");
	JButton resetButton = new JButton("Reset");

	RegistrationForm() {
		createWindow();
		setLocationAndSize();
		addComponentsToFrame();
		actionEvent();
	}

	public void createWindow() {
		frame = new JFrame();
		frame.setTitle("Registration Form");
		frame.setBounds(40, 40, 380, 600);
		frame.getContentPane().setBackground(Color.pink);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
	}

	public void setLocationAndSize() {
		nameLabel.setBounds(20, 20, 80, 70);
		genderLabel.setBounds(20, 70, 80, 70);
		fatherNameLabel.setBounds(20, 120, 100, 70);
		passwordLabel.setBounds(20, 170, 100, 70);
		confirmPasswordLabel.setBounds(20, 220, 140, 70);
		cityLabel.setBounds(20, 270, 100, 70);
		emailLabel.setBounds(20, 320, 100, 70);
		nameTextField.setBounds(180, 43, 165, 23);
		genderComboBox.setBounds(180, 93, 165, 23);
		userTextField.setBounds(180, 143, 165, 23);
		passwordField.setBounds(180, 193, 165, 23);
		confirmPasswordField.setBounds(180, 243, 165, 23);
		heightTextField.setBounds(180, 293, 165, 23);
		weightTextField.setBounds(180, 343, 165, 23);
		registerButton.setBounds(70, 400, 100, 35);
		resetButton.setBounds(220, 400, 100, 35);
	}

	public void addComponentsToFrame() {
		frame.add(nameLabel);
		frame.add(genderLabel);
		frame.add(fatherNameLabel);
		frame.add(passwordLabel);
		frame.add(confirmPasswordLabel);
		frame.add(cityLabel);
		frame.add(emailLabel);
		frame.add(nameTextField);
		frame.add(genderComboBox);
		frame.add(userTextField);
		frame.add(passwordField);
		frame.add(confirmPasswordField);
		frame.add(heightTextField);
		frame.add(weightTextField);
		frame.add(registerButton);
		frame.add(resetButton);
	}

	public void actionEvent() {
		registerButton.addActionListener(this);
		resetButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == registerButton) {
			try {
				// Creating Connection Object
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql_database",
						"root", "root");
				// Preapared Statement
				PreparedStatement Pstatement = connection.prepareStatement("insert into users values(?,?,?,?,?)");
				// Specifying the values of it's parameter
				Pstatement.setString(1, nameTextField.getText());

				Pstatement.setString(2, userTextField.getText());
				Pstatement.setString(3, passwordField.getText());

				Pstatement.setString(4, heightTextField.getText());
				Pstatement.setString(5, weightTextField.getText());
				// Checking for the Password match
				if (passwordField.getText().equalsIgnoreCase(confirmPasswordField.getText())) {
					// Executing query
					Pstatement.executeUpdate();
					frame.dispose();
					JOptionPane.showMessageDialog(null, "You Were Registered Successfully!!!");
				} else {
					JOptionPane.showMessageDialog(null, "password did not match");
				}

			} catch (SQLException e1) {
				e1.printStackTrace();
			}

		}
		if (e.getSource() == resetButton) {
			// Clearing Fields
			nameTextField.setText("");
			genderComboBox.setSelectedItem("Male");
			userTextField.setText("");
			passwordField.setText("");
			confirmPasswordField.setText("");
			heightTextField.setText("");
			weightTextField.setText("");
		}

	}

}