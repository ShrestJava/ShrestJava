package JDBC_SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class User_Info {
	public static String n1;
	public static String n2;
	public static String Name;

	public static void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql_database", "root", "root");
			Statement s = con.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM users where `Full Name` = '" + Name + "'");

			while (r.next()) {

				n1 = r.getString("Height");
				n2 = r.getString("Weight");
				System.out.println(n1 + "        " + n2);
			}

		} catch (ClassNotFoundException e) {
			Logger.getLogger(User_Info.class.getName()).log(Level.SEVERE, null, e);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		User_Info t = new User_Info();
		createConnection();
	}
}
